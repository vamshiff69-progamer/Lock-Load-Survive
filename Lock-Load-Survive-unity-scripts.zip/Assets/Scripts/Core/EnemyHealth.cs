using UnityEngine;
using System;
using System.Collections.Generic;

public interface IDamageable
{
    void TakeDamage(float amount, Vector3 hitPoint, DamageType damageType, GameObject instigator);
}

public class EnemyHealth : MonoBehaviour, IDamageable
{
    [Header("Health Settings")]
    [SerializeField] private float maxHealth = 100f;
    [SerializeField] private float currentHealth;
    [SerializeField] private float headshotDamageMultiplier = 2.0f;
    [SerializeField] private List<WeakPoint> weakPoints; // Define specific weak points for extra damage

    [Header("Death Settings")]
    [SerializeField] private GameObject deathEffectPrefab;
    [SerializeField] private float deathEffectDuration = 2f;
    [SerializeField] private GameObject hitEffectPrefab;
    [SerializeField] private float hitEffectDuration = 1f;
    [SerializeField] private float deathAnimationDuration = 3f; // Assumed duration for a death animation

    // Events for other systems to subscribe to
    public static event Action<GameObject, float, DamageType, GameObject> OnEnemyDamaged; // Enemy, damageDealt, damageType, instigator
    public static event Action<GameObject, GameObject> OnEnemyDied; // Died enemy, instigator

    private EnemyAIController enemyAIController;
    private Collider[] allColliders;
    private Rigidbody[] allRigidbodies;
    private Animator animator;
    private bool isDead = false;

    [System.Serializable]
    public class WeakPoint
    {
        public Collider collider;
        public float damageMultiplier = 1.5f;
    }

    private void Awake()
    {
        currentHealth = maxHealth;
        enemyAIController = GetComponent<EnemyAIController>();
        allColliders = GetComponentsInChildren<Collider>();
        allRigidbodies = GetComponentsInChildren<Rigidbody>();
        animator = GetComponent<Animator>();

        if (enemyAIController == null)
        {
            Debug.LogWarning($"EnemyHealth on {gameObject.name} could not find EnemyAIController. Death effects may not properly disable AI.", this);
        }
    }

    /// <summary>
    /// Handles incoming damage to the enemy.
    /// </summary>
    /// <param name="amount">The base damage amount.</param>
    /// <param name="hitPoint">The world position where the hit occurred.</param>
    /// <param name="damageType">The type of damage (e.g., Generic, Headshot, Explosive).</param>
    /// <param name="instigator">The GameObject that dealt the damage (e.g., Player).</param>
    public void TakeDamage(float amount, Vector3 hitPoint, DamageType damageType, GameObject instigator)
    {
        if (isDead)
        {
            return;
        }

        float finalDamage = amount;

        // Apply damage multiplier for specific weak points if the hit collider is one of them
        foreach (var weakPoint in weakPoints)
        {
            if (weakPoint.collider != null && hitPoint != Vector3.zero && weakPoint.collider.ClosestPoint(hitPoint) == hitPoint) // Simple check if hit was on weakpoint collider
            {
                finalDamage *= weakPoint.damageMultiplier;
                // Debug.Log($"Hit weak point for {weakPoint.damageMultiplier}x damage!");
                break;
            }
        }

        // Apply headshot multiplier if the damage type is headshot.
        // Note: Weapon.cs already handles this by sending an adjusted damage amount and DamageType.Headshot.
        // If there's a need to apply additional multipliers here based on body part hit,
        // the `damageType` parameter can be used to further refine (e.g., specific headshot weak points).
        // For simplicity and to avoid double-dipping with Weapon.cs logic, we trust the `damageType` provided.
        if (damageType == DamageType.Headshot)
        {
            finalDamage *= headshotDamageMultiplier;
        }

        currentHealth -= finalDamage;
        currentHealth = Mathf.Max(currentHealth, 0f); // Ensure health doesn't go below zero

        // Notify UI for hit markers / damage numbers
        UIManager.Instance?.ShowDamageIndicator(finalDamage, hitPoint, damageType); // Assuming UIManager has this method

        // Notify ParticleEffectManager for hit effects
        ParticleEffectManager.Instance?.SpawnEffect(hitEffectPrefab, hitPoint, Quaternion.identity, hitEffectDuration); // Assuming ParticleEffectManager has this method

        OnEnemyDamaged?.Invoke(gameObject, finalDamage, damageType, instigator);

        if (currentHealth <= 0 && !isDead)
        {
            Die(instigator);
        }
    }

    /// <summary>
    /// Returns the current health of the enemy.
    /// </summary>
    public float GetCurrentHealth()
    {
        return currentHealth;
    }

    /// <summary>
    /// Handles the enemy death sequence.
    /// </summary>
    /// <param name="instigator">The GameObject that delivered the killing blow.</param>
    private void Die(GameObject instigator)
    {
        isDead = true;

        // Disable AI to stop further actions
        if (enemyAIController != null)
        {
            enemyAIController.DisableAI();
        }

        // Trigger death animation
        if (animator != null)
        {
            animator.SetTrigger("Die");
            // Disable other colliders or rigidbodies if ragdoll is used
            SetCollidersAndRigidbodies(false, true); // Disable regular colliders, enable ragdoll rigidbodies/colliders
        }
        else
        {
            SetCollidersAndRigidbodies(false, false); // If no animator, just disable all for now
        }

        // Spawn death effect
        if (deathEffectPrefab != null)
        {
            ParticleEffectManager.Instance?.SpawnEffect(deathEffectPrefab, transform.position, Quaternion.identity, deathEffectDuration);
        }

        // Publish death event
        OnEnemyDied?.Invoke(gameObject, instigator);

        // Optionally, destroy or pool the enemy GameObject after a delay
        // For production, pooling is preferred for performance.
        if (gameObject.activeInHierarchy) // Check if still active before starting coroutine
        {
            StartCoroutine(HandleDeathCleanup());
        }
    }

    /// <summary>
    /// Coroutine to handle cleanup after death, such as disabling or pooling the GameObject.
    /// </summary>
    private System.Collections.IEnumerator HandleDeathCleanup()
    {
        yield return new WaitForSeconds(deathAnimationDuration); // Wait for death animation to play

        // In a production scenario, you would typically use an object pooling system here.
        // For now, we simply deactivate the GameObject.
        gameObject.SetActive(false); 
        // Or if pooling: ObjectPoolManager.Instance.ReturnObject(gameObject);
    }

    /// <summary>
    /// Enables or disables all colliders and rigidbodies on the enemy and its children.
    /// Useful for ragdolls or disabling interaction upon death.
    /// </summary>
    /// <param name="enableColliders">Whether to enable colliders.</param>
    /// <param name="enableRigidbodies">Whether to enable rigidbodies (typically for ragdolls).</param>
    private void SetCollidersAndRigidbodies(bool enableColliders, bool enableRigidbodies)
    {
        foreach (Collider col in allColliders)
        {
            if (col != null) col.enabled = enableColliders;
        }
        foreach (Rigidbody rb in allRigidbodies)
        {
            if (rb != null)
            {
                rb.isKinematic = !enableRigidbodies;
                // If it's a ragdoll, ensure gravity is on if rigidbodies are enabled
                if (enableRigidbodies) rb.useGravity = true;
                else rb.useGravity = false;
            }
        }
        // If you have a main character controller collider, you might want to disable it specifically
        // if it's not part of the `allColliders` array and you want to ensure it's off.
        Collider mainCollider = GetComponent<Collider>();
        if (mainCollider != null) mainCollider.enabled = enableColliders;
    }

    /// <summary>
    /// Resets the enemy's state for potential re-use via pooling.
    /// </summary>
    public void ResetEnemyState()
    {
        currentHealth = maxHealth;
        isDead = false;
        // Re-enable AI
        if (enemyAIController != null)
        {
            enemyAIController.EnableAI();
        }
        // Re-enable colliders for interaction
        SetCollidersAndRigidbodies(true, false); // Enable regular colliders, disable ragdoll rigidbodies
        // Reset animator state if applicable
        if (animator != null)
        {
            animator.Rebind();
            animator.Update(0f); // Force update to reset blend tree
        }
        gameObject.SetActive(true);
    }
}