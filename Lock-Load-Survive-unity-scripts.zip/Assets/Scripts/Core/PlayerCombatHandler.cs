using UnityEngine;
using System.Collections.Generic;
using System;

public class PlayerCombatHandler : MonoBehaviour
{
    [SerializeField] private List<Weapon> availableWeapons = new List<Weapon>();
    [SerializeField] private Transform weaponHoldPoint;
    [SerializeField] private LayerMask enemyLayers;

    private Weapon _currentWeapon;
    private int _currentWeaponIndex = -1;
    private GameObject _currentWeaponGameObject;

    private Action _switchWeapon1Delegate;
    private Action _switchWeapon2Delegate;
    private Action _switchWeapon3Delegate;

    public static event Action<float, Vector3, DamageType, GameObject> OnPlayerDamageDealt;
    public static event Action<int, int> OnAmmoChanged;

    private void Awake()
    {
        if (weaponHoldPoint == null)
        {
            Debug.LogError("PlayerCombatHandler: weaponHoldPoint not assigned. Weapons will not be correctly positioned.", this);
        }

        if (availableWeapons == null || availableWeapons.Count == 0)
        {
            Debug.LogError("PlayerCombatHandler: No weapons assigned to availableWeapons list.", this);
        }
    }

    private void Start()
    {
        if (availableWeapons != null && availableWeapons.Count > 0)
        {
            SwitchWeapon(0);
        }
        else
        {
            Debug.LogError("PlayerCombatHandler: Cannot initialize without any weapons. Please assign weapons in the Inspector.", this);
        }
    }

    private void OnEnable()
    {
        PlayerCharacterController.OnPlayerFireInput += FireWeapon;
        PlayerCharacterController.OnPlayerReloadInput += ReloadWeapon;

        _switchWeapon1Delegate = () => SwitchWeapon(0);
        InputManager.OnSwitchWeapon1Action += _switchWeapon1Delegate;
        _switchWeapon2Delegate = () => SwitchWeapon(1);
        InputManager.OnSwitchWeapon2Action += _switchWeapon2Delegate;
        _switchWeapon3Delegate = () => SwitchWeapon(2);
        InputManager.OnSwitchWeapon3Action += _switchWeapon3Delegate;
    }

    private void OnDisable()
    {
        PlayerCharacterController.OnPlayerFireInput -= FireWeapon;
        PlayerCharacterController.OnPlayerReloadInput -= ReloadWeapon;

        if (_switchWeapon1Delegate != null) InputManager.OnSwitchWeapon1Action -= _switchWeapon1Delegate;
        if (_switchWeapon2Delegate != null) InputManager.OnSwitchWeapon2Action -= _switchWeapon2Delegate;
        if (_switchWeapon3Delegate != null) InputManager.OnSwitchWeapon3Action -= _switchWeapon3Delegate;

        if (_currentWeapon != null)
        {
            _currentWeapon.OnDamageDealtExternally -= NotifyDamageDealt;
        }
    }

    private void Update()
    {
        _currentWeapon?.UpdateWeapon(Time.deltaTime);
    }

    public void FireWeapon()
    {
        if (_currentWeapon == null)
        {
            Debug.LogWarning("PlayerCombatHandler: No weapon equipped to fire.");
            return;
        }

        if (!_currentWeapon.CanFire())
        {
            return;
        }

        Vector3 fireOrigin = weaponHoldPoint.position;
        Vector3 fireDirection = weaponHoldPoint.forward;

        _currentWeapon.Fire(fireOrigin, fireDirection, enemyLayers);

        if (_currentWeapon != null)
        {
            OnAmmoChanged?.Invoke(_currentWeapon.GetCurrentAmmo(), _currentWeapon.GetMaxClipAmmo());
        }
    }

    public void ReloadWeapon()
    {
        if (_currentWeapon == null)
        {
            Debug.LogWarning("PlayerCombatHandler: No weapon equipped to reload.");
            return;
        }

        _currentWeapon.Reload();

        if (_currentWeapon != null)
        {
            OnAmmoChanged?.Invoke(_currentWeapon.GetCurrentAmmo(), _currentWeapon.GetMaxClipAmmo());
        }
    }

    public void SwitchWeapon(int weaponIndex)
    {
        if (weaponIndex < 0 || weaponIndex >= availableWeapons.Count)
        {
            Debug.LogWarning($"PlayerCombatHandler: Invalid weapon index {weaponIndex}. Available weapons: {availableWeapons.Count}.");
            return;
        }

        if (_currentWeaponIndex == weaponIndex)
        {
            return;
        }

        if (_currentWeapon != null)
        {
            _currentWeapon.OnDamageDealtExternally -= NotifyDamageDealt;
        }

        if (_currentWeaponGameObject != null)
        {
            Destroy(_currentWeaponGameObject);
        }

        _currentWeaponIndex = weaponIndex;
        _currentWeapon = availableWeapons[weaponIndex];

        if (_currentWeapon.GetWeaponPrefab() != null && weaponHoldPoint != null)
        {
            _currentWeaponGameObject = Instantiate(_currentWeapon.GetWeaponPrefab(), weaponHoldPoint.position, weaponHoldPoint.rotation, weaponHoldPoint);
            _currentWeaponGameObject.name = $"{_currentWeapon.name}_Instance";
        }
        else if (_currentWeapon.GetWeaponPrefab() == null)
        {
            Debug.LogWarning($"PlayerCombatHandler: Weapon '{_currentWeapon.name}' has no prefab assigned. No model will be displayed.", this);
        }

        _currentWeapon.OnDamageDealtExternally += NotifyDamageDealt;

        Debug.Log($"PlayerCombatHandler: Switched to weapon: {_currentWeapon.name}");

        if (_currentWeapon != null)
        {
            OnAmmoChanged?.Invoke(_currentWeapon.GetCurrentAmmo(), _currentWeapon.GetMaxClipAmmo());
        }
    }

    public void NotifyDamageDealt(float damageAmount, Vector3 hitPoint, DamageType damageType, GameObject instigator)
    {
        OnPlayerDamageDealt?.Invoke(damageAmount, hitPoint, damageType, instigator);
    }
}