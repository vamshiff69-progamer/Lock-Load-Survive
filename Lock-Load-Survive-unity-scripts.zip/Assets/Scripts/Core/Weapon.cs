using UnityEngine;
using System;
using System.Collections;

public enum DamageType { Generic, Headshot, Explosive, Melee }

[CreateAssetMenu(fileName = "NewWeapon", menuName = "Weapons/Weapon")]
public class Weapon : ScriptableObject
{
    [Header("Weapon Settings")]
    [SerializeField] private string weaponName = "New Weapon";
    [SerializeField] private GameObject weaponPrefab;
    [SerializeField] private float damage = 10f;
    [SerializeField] private float fireRate = 0.1f; // Time between shots
    [SerializeField] private int magazineSize = 30;
    [SerializeField] private float reloadTime = 2f;
    [SerializeField] private int totalReserveAmmo = 90; // Total ammo available beyond current magazine
    [SerializeField] private GameObject projectilePrefab; // For projectile-based weapons
    [SerializeField] private float projectileSpeed = 50f; // Speed for projectile-based weapons
    [SerializeField] private float hitscanRange = 100f; // Range for hitscan weapons
    [SerializeField] private float spreadAngle = 1f; // Degrees of spread
    [SerializeField] private float recoilKick = 0.1f; // Vertical recoil intensity
    [SerializeField] private AudioClip fireSound;
    [SerializeField] private AudioClip reloadSound;

    [Header("Raycast Hit Settings")]
    [SerializeField] private float headshotMultiplier = 2f; // Damage multiplier for headshots
    [SerializeField] private string headshotTag = "Head"; // Tag to identify headshot hitboxes

    private int _currentAmmo;
    private float _nextFireTime;
    private bool _isReloading;
    private Coroutine _reloadCoroutine; // Store the coroutine to stop it if weapon is switched

    // Events for other systems to subscribe to
    public static event Action<Weapon> OnWeaponFired;
    public static event Action<Weapon> OnWeaponReloaded;
    public static event Action<Weapon, int, int> OnAmmoChanged; // Weapon, currentAmmo, magazineSize

    private void OnEnable()
    {
        // No initialization here. State should be managed by MonoBehaviour that uses it.
    }

    public void InitializeWeaponState()
    {
        _currentAmmo = magazineSize;
        _nextFireTime = 0f;
        _isReloading = false;
        // totalReserveAmmo logic might also need to be reset/managed from PlayerCombatHandler
    }

    public bool CanFire()
    {
        if (_isReloading || Time.time < _nextFireTime || _currentAmmo <= 0)
        {
            return false;
        }
        return true;
    }

    public void Fire(Vector3 origin, Vector3 direction, LayerMask targetLayers)
    {
        if (!CanFire())
        {
            return;
        }

        _currentAmmo--;
        _nextFireTime = Time.time + fireRate;

        // Apply spread
        Quaternion spreadRotation = Quaternion.Euler(UnityEngine.Random.Range(-spreadAngle, spreadAngle), UnityEngine.Random.Range(-spreadAngle, spreadAngle), 0);
        Vector3 fireDirection = spreadRotation * direction;

        if (projectilePrefab != null)
        {
            // Projectile-based weapon
            GameObject projectile = Instantiate(projectilePrefab, origin, Quaternion.LookRotation(fireDirection));
            if (projectile.TryGetComponent<Rigidbody>(out Rigidbody rb))
            {
                rb.velocity = fireDirection * projectileSpeed;
            }
            else
            {
                Debug.LogWarning($"Weapon '{weaponName}': Projectile prefab '{projectilePrefab.name}' is missing a Rigidbody component for propulsion.", this);
            }
            // Projectile script will handle damage on collision
        }
        else
        {
            // Hitscan weapon
            RaycastHit hit;
            if (Physics.Raycast(origin, fireDirection, out hit, hitscanRange, targetLayers))
            {
                float damageDealt = damage;
                DamageType damageType = DamageType.Generic;

                if (hit.collider.CompareTag(headshotTag))
                {
                    damageDealt *= headshotMultiplier;
                    damageType = DamageType.Headshot;
                }

                if (hit.collider.TryGetComponent<IDamageable>(out IDamageable damageable))
                {
                    damageable.TakeDamage(damageDealt, hit.point, damageType, null); // Instigator is null for now, can be player GameObject
                }
            }
        }

        OnWeaponFired?.Invoke(this);
        OnAmmoChanged?.Invoke(this, _currentAmmo, magazineSize);
    }

    public void Reload()
    {
        // Reload functionality is now handled by StartReloadManaged in PlayerCombatHandler
        // This method can be removed or left empty if nothing needs to happen directly from here.
        // For example, if you wanted to log an attempt to reload, you could do so here.
        Debug.Log($"Attempting to reload {weaponName}. PlayerCombatHandler should initiate.");
    }

    private IEnumerator ReloadCoroutine()
    {
        _isReloading = true;
        OnWeaponReloaded?.Invoke(this); // Event for start of reload (e.g., sound, animation)

        yield return new WaitForSeconds(reloadTime);

        int ammoNeeded = magazineSize - _currentAmmo;
        int ammoToLoad = Mathf.Min(ammoNeeded, totalReserveAmmo);

        _currentAmmo += ammoToLoad;
        totalReserveAmmo -= ammoToLoad;

        _isReloading = false;
        OnAmmoChanged?.Invoke(this, _currentAmmo, magazineSize);
    }

    public float GetDamage()
    {
        return damage;
    }

    public int GetCurrentAmmo()
    {
        return _currentAmmo;
    }

    public int GetMaxClipAmmo()
    {
        return magazineSize;
    }

    public GameObject GetWeaponPrefab()
    {
        return weaponPrefab;
    }

    // This method is called by PlayerCombatHandler to update internal states like cooldowns
    public void UpdateWeapon(float deltaTime)
    {
        // For now, only relevant for _nextFireTime in CanFire check
    }

    public void StartReloadManaged(MonoBehaviour coroutineRunner)
    {
        if (_isReloading || _currentAmmo == magazineSize || totalReserveAmmo <= 0)
        {
            return;
        }
        _reloadCoroutine = coroutineRunner.StartCoroutine(ReloadCoroutine());
    }

    public void StopReloadManaged(MonoBehaviour coroutineRunner)
    {
        if (_reloadCoroutine != null)
        {
            coroutineRunner.StopCoroutine(_reloadCoroutine);
            _reloadCoroutine = null;
            _isReloading = false;
        }
    }
}