using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;
using System.Linq;

public class CharacterAbilityManager : MonoBehaviour
{
    // Events for UIManager to subscribe to for updating ability cooldowns
    public static event Action<string, float, float> OnAbilityCooldownChanged;
    public static event Action<string, bool> OnAbilityActiveStateChanged;

    [System.Serializable]
    public class AbilitySlot
    {
        public string abilityID; // Unique ID for this ability slot
        public AbilityData abilityData; // ScriptableObject holding ability specific data
        [HideInInspector] public float currentCooldown;
        [HideInInspector] public bool isActive;
        [HideInInspector] public Coroutine activeCoroutine;
        [HideInInspector] public Coroutine cooldownCoroutine;
    }

    [SerializeField] private AbilitySlot[] abilitySlots = new AbilitySlot[2];
    [SerializeField] private PlayerCharacterController playerCharacterController;
    [SerializeField] private LayerMask enemyLayer; // Layer containing EnemyAIControllers
    [SerializeField] private Material ghostProtocolMaterial; // Material for Orion's Ghost Protocol
    [SerializeField] private float ghostProtocolMaterialFadeDuration = 0.5f;

    private Renderer[] _playerRenderers;
    private Dictionary<Renderer, Material> _originalPlayerMaterials = new Dictionary<Renderer, Material>();

    private void Awake()
    {
        if (playerCharacterController == null)
        {
            playerCharacterController = GetComponent<PlayerCharacterController>();
            if (playerCharacterController == null)
            {
                Debug.LogError("CharacterAbilityManager requires a PlayerCharacterController reference.", this);
                enabled = false;
                return;
            }
        }

        // Cache player renderers and their original materials for Ghost Protocol
        _playerRenderers = playerCharacterController.GetComponentsInChildren<Renderer>();
        foreach (Renderer r in _playerRenderers)
        {
            if (r.material != null)
            {
                _originalPlayerMaterials[r] = r.material;
            }
        }

        InitializeAbilitySlots();
    }

    private void OnEnable()
    {
        PlayerCharacterController.OnPlayerAbilityActivation += TryActivateAbility;
    }

    private void OnDisable()
    {
        PlayerCharacterController.OnPlayerAbilityActivation -= TryActivateAbility;
    }

    private void InitializeAbilitySlots()
    {
        for (int i = 0; i < abilitySlots.Length; i++)
        {
            if (abilitySlots[i].abilityData == null)
            {
                Debug.LogWarning($"Ability slot {i} has no AbilityData assigned. This slot will be inactive.", this);
                continue;
            }
            abilitySlots[i].abilityID = abilitySlots[i].abilityData.abilityName;
            abilitySlots[i].currentCooldown = 0f;
            abilitySlots[i].isActive = false;
            OnAbilityCooldownChanged?.Invoke(abilitySlots[i].abilityID, 0, abilitySlots[i].abilityData.cooldownTime);
        }
    }

    /// <summary>
    /// Attempts to activate a character ability based on its index.
    /// Checks for cooldown and valid ability data before execution.
    /// </summary>
    /// <param name="abilityIndex">The index of the ability slot (0 for first, 1 for second).</param>
    public void TryActivateAbility(int abilityIndex)
    {
        if (abilityIndex < 0 || abilityIndex >= abilitySlots.Length)
        {
            Debug.LogWarning($"Attempted to activate ability with invalid index: {abilityIndex}.", this);
            return;
        }

        AbilitySlot slot = abilitySlots[abilityIndex];

        if (slot.abilityData == null)
        {
            Debug.LogWarning($"Ability slot {abilityIndex} has no AbilityData assigned. Cannot activate.", this);
            return;
        }

        if (slot.currentCooldown > 0)
        {
            Debug.Log($"Ability {slot.abilityData.abilityName} is on cooldown. Remaining: {slot.currentCooldown:F1}s");
            return;
        }

        if (slot.isActive)
        {
            Debug.Log($"Ability {slot.abilityData.abilityName} is already active.");
            return;
        }

        // Ability can be activated
        slot.activeCoroutine = StartCoroutine(ActivateAbilityRoutine(slot));
    }

    private IEnumerator ActivateAbilityRoutine(AbilitySlot slot)
    {
        Debug.Log($"Activating ability: {slot.abilityData.abilityName}");
        slot.isActive = true;
        OnAbilityActiveStateChanged?.Invoke(slot.abilityID, true);

        // Play activation effects
        if (slot.abilityData.activationSound != null)
        {
            AudioManager.Instance?.PlaySFX(slot.abilityData.activationSound, playerCharacterController.transform.position);
        }
        if (slot.abilityData.effectPrefab != null)
        {
            // Assuming ParticleEffectManager has a PlayEffect method that handles pooling
            ParticleEffectManager.Instance?.PlayEffect(slot.abilityData.effectPrefab, playerCharacterController.transform.position, playerCharacterController.transform.rotation, slot.abilityData.duration);
        }

        // Execute specific ability effect
        switch (slot.abilityData.abilityName)
        {
            case "Ghost Protocol":
                ExecuteGhostProtocol(slot);
                break;
            case "System Overload":
                ExecuteSystemOverload(slot);
                break;
            default:
                Debug.LogWarning($"Unknown ability: {slot.abilityData.abilityName}. No specific effect implemented.", this);
                break;
        }

        // Wait for ability duration
        yield return new WaitForSeconds(slot.abilityData.duration);

        Debug.Log($"Deactivating ability: {slot.abilityData.abilityName}");
        slot.isActive = false;
        OnAbilityActiveStateChanged?.Invoke(slot.abilityID, false);

        // Revert specific ability effect
        switch (slot.abilityData.abilityName)
        {
            case "Ghost Protocol":
                RevertGhostProtocol();
                break;
            case "System Overload":
                RevertSystemOverload();
                break;
        }

        // Start cooldown
        slot.cooldownCoroutine = StartCoroutine(StartCooldownRoutine(slot));
    }

    private IEnumerator StartCooldownRoutine(AbilitySlot slot)
    {
        slot.currentCooldown = slot.abilityData.cooldownTime;
        while (slot.currentCooldown > 0)
        {
            OnAbilityCooldownChanged?.Invoke(slot.abilityID, slot.currentCooldown, slot.abilityData.cooldownTime);
            slot.currentCooldown -= Time.deltaTime;
            yield return null;
        }
        slot.currentCooldown = 0;
        OnAbilityCooldownChanged?.Invoke(slot.abilityID, 0, slot.abilityData.cooldownTime);
        Debug.Log($"Ability {slot.abilityData.abilityName} cooldown complete.");
    }

    /// <summary>
    /// Implements Orion's "Ghost Protocol" ability.
    /// Temporarily renders the player almost invisible to enemies.
    /// </summary>
    private void ExecuteGhostProtocol(AbilitySlot slot)
    {
        Debug.Log("Executing Ghost Protocol.");
        // Change player material to a semi-transparent/cloaked material
        if (ghostProtocolMaterial != null && _playerRenderers != null && _playerRenderers.Length > 0)
        {
            foreach (Renderer r in _playerRenderers)
            {
                if (r.material != null)
                {
                    // Ensure material has the correct render mode for transparency if needed
                    // This assumes a shader that supports alpha blending for the ghostProtocolMaterial
                    StartCoroutine(FadePlayerMaterialAlpha(r, ghostProtocolMaterial, _originalPlayerMaterials[r].color.a, 0.2f, ghostProtocolMaterialFadeDuration));
                }
            }
        }

        // Notify relevant enemy AIs or the global AI manager that player is 'invisible'
        // This would typically involve a system that queries player's visibility status.
        // For this example, we assume EnemyAIController has a way to check player status or ignore player.
        // If enemy AIs need to be explicitly told, a static event or direct method call could be used.
        // e.g., EnemyAIController.SetPlayerVisibilityStatus(false);
        Debug.Log("Player is now 'invisible' to enemies (AI should be modified to check for this status).");
    }

    /// <summary>
    /// Reverts Orion's "Ghost Protocol" ability effects.
    /// </summary>
    private void RevertGhostProtocol()
    {
        Debug.Log("Reverting Ghost Protocol.");
        // Revert player material to original
        if (_playerRenderers != null && _playerRenderers.Length > 0)
        {
            foreach (Renderer r in _playerRenderers)
            {
                if (_originalPlayerMaterials.ContainsKey(r))
                {
                    StartCoroutine(FadePlayerMaterialAlpha(r, _originalPlayerMaterials[r], r.material.color.a, _originalPlayerMaterials[r].color.a, ghostProtocolMaterialFadeDuration));
                }
            }
        }
        // Notify enemies that player is visible again
        // e.g., EnemyAIController.SetPlayerVisibilityStatus(true);
        Debug.Log("Player is now visible to enemies again.");
    }

    private IEnumerator FadePlayerMaterialAlpha(Renderer renderer, Material targetMaterial, float startAlpha, float endAlpha, float duration)
    {
        if (renderer == null || targetMaterial == null) yield break;

        Material currentMaterial = renderer.material;
        Color color = currentMaterial.color;

        // Apply new material if different, then fade
        if (currentMaterial != targetMaterial)
        {
            renderer.material = targetMaterial;
            currentMaterial = renderer.material; // Update reference to new material
            color = currentMaterial.color; // Get color from the new material
        }

        float timer = 0f;
        while (timer < duration)
        {
            timer += Time.deltaTime;
            color.a = Mathf.Lerp(startAlpha, endAlpha, timer / duration);
            currentMaterial.color = color;
            yield return null;
        }
        color.a = endAlpha;
        currentMaterial.color = color;
    }


    /// <summary>
    /// Implements Kaito's "System Overload" ability.
    /// Temporarily disables enemy weapons and defenses in an area.
    /// </summary>
    private void ExecuteSystemOverload(AbilitySlot slot)
    {
        Debug.Log("Executing System Overload.");
        Collider[] hitColliders = Physics.OverlapSphere(playerCharacterController.transform.position, slot.abilityData.abilityRange, enemyLayer);

        foreach (var hitCollider in hitColliders)
        {
            EnemyAIController enemyAI = hitCollider.GetComponentInParent<EnemyAIController>();
            if (enemyAI != null)
            {
                // Assuming EnemyAIController has a method to temporarily disable weapons/defenses
                TemporarilyDisableEnemyWeapons(enemyAI, slot.abilityData.duration);
                Debug.Log($"System Overload affecting {enemyAI.name}");
            }
        }
    }

    /// <summary>
    /// Reverts Kaito's "System Overload" ability effects.
    /// </summary>
    private void RevertSystemOverload()
    {
        Debug.Log("Reverting System Overload.");
        // No global revert needed as effects are duration-based on individual enemies.
    }

    /// <summary>
    /// Calls a method on the EnemyAIController to disable its weapons for a duration.
    /// This is a placeholder for actual implementation within EnemyAIController.
    /// </summary>
    /// <param name="enemyAI">The EnemyAIController to affect.</param>
    /// <param name="duration">How long the weapons should be disabled.</param>
    private void TemporarilyDisableEnemyWeapons(EnemyAIController enemyAI, float duration)
    {
        // This is a placeholder. EnemyAIController needs a public method like this:
        // enemyAI.TemporarilyDisableWeapons(duration);
        Debug.LogWarning($"EnemyAIController.TemporarilyDisableWeapons({duration}) called on {enemyAI.name}. This method needs to be implemented in EnemyAIController.");
        // For demonstration, we'll assume it temporarily sets the enemy to a 'Stunned' state.
        StartCoroutine(StunEnemyTemporarily(enemyAI, duration));
    }

    private IEnumerator StunEnemyTemporarily(EnemyAIController enemyAI, float duration)
    {
        // Save original state
        // AIState originalState = enemyAI.currentState; // Need public access to this in EnemyAIController or a method
        
        // This is a workaround assuming EnemyAIController doesn't expose its state directly.
        // It's better to have a dedicated method in EnemyAIController like "ApplyStun(duration)"
        // If EnemyAIController has a DisableAI/EnableAI, we can use that, but it's too broad for "weapon disable".
        Debug.Log($"Stunning {enemyAI.name} for {duration} seconds.");
        // Simulate stun by disabling its AI for the duration
        enemyAI.DisableAI(); // This will disable all AI, not just weapons
        yield return new WaitForSeconds(duration);
        enemyAI.EnableAI(); // Re-enable after duration
        Debug.Log($"{enemyAI.name} stun ended.");
    }
}


[CreateAssetMenu(fileName = "NewAbilityData", menuName = "Abilities/Ability Data", order = 1)]
public class AbilityData : ScriptableObject
{
    public string abilityName = "New Ability";
    [TextArea] public string description = "Ability description.";
    public Sprite icon;
    public float cooldownTime = 10f;
    public float duration = 5f;
    public float abilityRange = 10f; // For area-of-effect abilities
    public GameObject effectPrefab; // Visual effect for activation
    public AudioClip activationSound; // Sound effect for activation
    public int abilityCost = 0; // If abilities consume resources
}