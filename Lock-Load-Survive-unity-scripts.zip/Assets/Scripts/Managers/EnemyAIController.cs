// Required Packages:
// - com.unity.modules.ai

using UnityEngine;
using UnityEngine.AI;
using System;
using System.Collections;
using Random = UnityEngine.Random;

public class EnemyAIController : MonoBehaviour, IDamageable
{
    // Public events for other systems
    public static event Action<GameObject, GameObject> OnEnemyKilled; // Enemy GameObject, Instigator GameObject

    [Header("Enemy Type Configuration")]
    [SerializeField] private EnemyType enemyType = EnemyType.BreacherBrute;
    public EnemyType GetEnemyType => enemyType;

    [Header("AI State & Debug")]
    [SerializeField] private AIState currentState = AIState.Idle;
    [SerializeField] private float playerDetectionRadius = 20f;
    [SerializeField] private LayerMask playerLayer;
    [SerializeField] private LayerMask obstacleLayer;

    [Header("Patrolling")]
    [SerializeField] private float patrolSpeed = 2f;
    [SerializeField] private float patrolWaypointTolerance = 1.5f;
    [SerializeField] private float patrolWaitTime = 2f;
    [SerializeField] private Transform[] patrolWaypoints;
    private int currentWaypointIndex = 0;
    private float waitTimer = 0f;

    [Header("Chasing")]
    [SerializeField] private float chaseSpeed = 4f;
    [SerializeField] private float losePlayerDistance = 30f;
    [SerializeField] private float playerSightClearanceHeight = 1.0f; // Offset to check player's head level

    [Header("Attacking")]
    [SerializeField] private float attackRange = 5f;
    [SerializeField] private float attackCooldown = 2f;
    [SerializeField] private bool canMoveWhileAttacking = false; // For Brutes, they might charge
    [SerializeField] private float attackWindupTime = 0.5f; // Time before actual attack damage
    [SerializeField] private GameObject enemyWeaponGameObject; // Assign the weapon GameObject for this enemy type
    private EnemyWeapon enemyWeapon;
    private float lastAttackTime = -Mathf.Infinity;

    [Header("Reaper Drone Specific")]
    [SerializeField] private float droneHoverHeight = 5f;
    [SerializeField] private float droneFlightSpeed = 6f;
    [SerializeField] private float droneStrafeSpeed = 3f;
    [SerializeField] private float droneStrafeDistance = 5f;
    [SerializeField] private float droneStrafeCooldown = 3f;
    private float lastStrafeTime;
    private Vector3 strafeTargetPosition;
    private bool isStrafing = false;

    [Header("Breacher Brute Specific")]
    [SerializeField] private float bruteChargeSpeed = 7f;
    [SerializeField] private float bruteChargeDistance = 10f;
    [SerializeField] private float bruteChargeCooldown = 5f;
    private float lastChargeTime;
    private bool isCharging = false;
    private Vector3 chargeStartPos;
    private Vector3 chargeTargetPos;

    [Header("Ghost Operative Specific")]
    [SerializeField] private float cloakDuration = 5f;
    [SerializeField] private float decloakDuration = 1f;
    [SerializeField] private float cloakCooldown = 10f;
    [SerializeField] private float sniperRange = 50f;
    private float lastCloakTime = -Mathf.Infinity;
    private bool isCloaked = false;
    private Renderer[] renderers; // For cloaking effect
    private Material[] originalMaterials;
    private Material cloakedMaterial; // Assign a cloaked material in inspector
    private Color originalAlbedoColor;
    private GameObject cloakedEffectPrefab; // VFX for cloaking/decloaking
    private Transform sniperVantagePoint; // Specific point Ghost Operative moves to

    private NavMeshAgent navMeshAgent;
    private Animator animator;
    private EnemyHealth enemyHealth;
    private GameObject playerTarget; // Reference to the player GameObject
    private bool aiActive = true;
    private Vector3 lastKnownPlayerPosition;

    public enum AIState
    {
        Idle,
        Patrol,
        Chase,
        Attack,
        Flee, // Could be used for low health scenarios
        Stunned,
        Dead
    }

    public enum EnemyType
    {
        ReaperDrone,
        BreacherBrute,
        GhostOperative
    }

    private void Awake()
    {
        navMeshAgent = GetComponent<NavMeshAgent>();
        animator = GetComponent<Animator>();
        enemyHealth = GetComponent<EnemyHealth>();
        enemyWeapon = enemyWeaponGameObject?.GetComponent<EnemyWeapon>();

        if (navMeshAgent == null) Debug.LogError("NavMeshAgent not found on " + gameObject.name);
        if (animator == null) Debug.LogWarning("Animator not found on " + gameObject.name);
        if (enemyHealth == null) Debug.LogError("EnemyHealth not found on " + gameObject.name);
        if (enemyWeapon == null && enemyType != EnemyType.BreacherBrute) Debug.LogWarning("EnemyWeapon not found on " + gameObject.name + ". Ensure 'enemyWeaponGameObject' is assigned with a valid EnemyWeapon component.");

        if (enemyType == EnemyType.ReaperDrone)
        {
            if (navMeshAgent != null) navMeshAgent.speed = droneFlightSpeed;
            if (navMeshAgent != null) navMeshAgent.stoppingDistance = attackRange - 1f;
        }
        else if (enemyType == EnemyType.BreacherBrute)
        {
            if (navMeshAgent != null) navMeshAgent.speed = patrolSpeed;
            if (navMeshAgent != null) navMeshAgent.stoppingDistance = attackRange - 0.5f;
        }
        else if (enemyType == EnemyType.GhostOperative)
        {
            renderers = GetComponentsInChildren<Renderer>();
            originalMaterials = new Material[renderers.Length];
            for (int i = 0; i < renderers.Length; i++)
            {
                originalMaterials[i] = renderers[i].material;
            }
            // For Ghost Operative, ensure a cloaked material is assigned in the inspector
            // if (cloakedMaterial == null) Debug.LogError("Ghost Operative: Cloaked Material not assigned in inspector!");
            if (navMeshAgent != null) navMeshAgent.speed = patrolSpeed;
            if (navMeshAgent != null) navMeshAgent.stoppingDistance = sniperRange * 0.8f; // Stay a bit further
        }

        // Initially hide the navMeshAgent if it's a drone, as its movement is custom
        if (enemyType == EnemyType.ReaperDrone && navMeshAgent != null)
        {
            navMeshAgent.enabled = false;
        }
    }

    private void Start()
    {
        // Player target could be found at start or passed in by a spawn manager
        playerTarget = GameObject.FindGameObjectWithTag("Player"); // Assuming player has "Player" tag

        if (enemyType == EnemyType.ReaperDrone)
        {
            lastStrafeTime = Time.time;
        }
        if (enemyType == EnemyType.BreacherBrute)
        {
            lastChargeTime = Time.time;
        }

        // Start in patrol state if waypoints exist, otherwise idle
        if (patrolWaypoints != null && patrolWaypoints.Length > 0)
        {
            SetState(AIState.Patrol);
        }
        else
        {
            SetState(AIState.Idle);
        }

        // Subscribe to death event from EnemyHealth to trigger OnEnemyKilled
        EnemyHealth.OnEnemyDied += HandleEnemyDiedGlobally;
    }

    private void OnDestroy()
    {
        EnemyHealth.OnEnemyDied -= HandleEnemyDiedGlobally;
    }

    private void Update()
    {
        if (!aiActive || currentState == AIState.Dead || currentState == AIState.Stunned) return;

        UpdateState();
        UpdateAnimatorParameters();
    }

    /// <summary>
    /// Implements the IDamageable interface.
    /// Redirects damage to EnemyHealth component.
    /// </summary>
    public void TakeDamage(float amount, Vector3 hitPoint, DamageType damageType, GameObject instigator)
    {
        enemyHealth.TakeDamage(amount, hitPoint, damageType, instigator);
        // If the enemy is hit, it might immediately focus on the instigator
        if (instigator != null && instigator.CompareTag("Player"))
        {
            playerTarget = instigator; // Ensure playerTarget is set to the instigator
            if (currentState != AIState.Chase && currentState != AIState.Attack)
            {
                SetState(AIState.Chase);
            }
        }
    }

    /// <summary>
    /// Drives the AI state machine logic.
    /// </summary>
    private void UpdateState()
    {
        switch (currentState)
        {
            case AIState.Idle:
                SearchForPlayer();
                break;
            case AIState.Patrol:
                Patrol();
                SearchForPlayer();
                break;
            case AIState.Chase:
                ChasePlayer();
                break;
            case AIState.Attack:
                AttackPlayer();
                break;
            case AIState.Flee:
                // Flee logic if implemented
                break;
        }
    }

    /// <summary>
    /// Searches for the player within playerDetectionRadius.
    /// If found and line of sight is clear, switches to Chase state.
    /// </summary>
    private void SearchForPlayer()
    {
        if (playerTarget == null) return;

        Collider[] hitColliders = Physics.OverlapSphere(transform.position, playerDetectionRadius, playerLayer);
        if (hitColliders.Length > 0)
        {
            // Assuming the first hit collider is the player
            // You might want more sophisticated logic for multiple players or specific checks
            Vector3 directionToPlayer = (playerTarget.transform.position - transform.position).normalized;
            float distanceToPlayer = Vector3.Distance(transform.position, playerTarget.transform.position);

            // Check line of sight
            RaycastHit hit;
            Vector3 eyeLevel = transform.position + Vector3.up * playerSightClearanceHeight;
            Vector3 playerEyeLevel = playerTarget.transform.position + Vector3.up * playerSightClearanceHeight;

            if (Physics.Raycast(eyeLevel, (playerEyeLevel - eyeLevel).normalized, out hit, distanceToPlayer, playerLayer | obstacleLayer))
            {
                if (hit.collider.gameObject == playerTarget)
                {
                    // Player detected and line of sight is clear
                    lastKnownPlayerPosition = playerTarget.transform.position;
                    SetState(AIState.Chase);
                }
            }
        }
    }

    /// <summary>
    /// Handles enemy patrolling behavior.
    /// </summary>
    private void Patrol()
    {
        if (navMeshAgent == null || !navMeshAgent.enabled || patrolWaypoints == null || patrolWaypoints.Length == 0) return;

        navMeshAgent.speed = patrolSpeed;
        navMeshAgent.isStopped = false;

        // Check if agent has reached the current waypoint
        if (!navMeshAgent.pathPending && navMeshAgent.remainingDistance < patrolWaypointTolerance)
        {
            waitTimer += Time.deltaTime;
            if (waitTimer >= patrolWaitTime)
            {
                waitTimer = 0f;
                currentWaypointIndex = (currentWaypointIndex + 1) % patrolWaypoints.Length;
                navMeshAgent.SetDestination(patrolWaypoints[currentWaypointIndex].position);
            }
        }
        else if (navMeshAgent.destination == Vector3.zero || navMeshAgent.destination != patrolWaypoints[currentWaypointIndex].position)
        {
            // Set initial destination or if it was somehow reset
            navMeshAgent.SetDestination(patrolWaypoints[currentWaypointIndex].position);
        }
    }

    /// <summary>
    /// Handles enemy chasing behavior, moving towards the player.
    /// </summary>
    private void ChasePlayer()
    {
        if (playerTarget == null)
        {
            SetState(AIState.Patrol); // Player somehow lost, go back to patrol
            return;
        }

        Vector3 currentTargetPosition = playerTarget.transform.position;

        // Check distance to player
        float distanceToPlayer = Vector3.Distance(transform.position, currentTargetPosition);

        // Check line of sight (similar to SearchForPlayer, but always tracking)
        RaycastHit hit;
        Vector3 eyeLevel = transform.position + Vector3.up * playerSightClearanceHeight;
        Vector3 playerEyeLevel = currentTargetPosition + Vector3.up * playerSightClearanceHeight;

        bool hasLineOfSight = Physics.Raycast(eyeLevel, (playerEyeLevel - eyeLevel).normalized, out hit, distanceToPlayer, playerLayer | obstacleLayer) &&
                              hit.collider.gameObject == playerTarget;

        if (hasLineOfSight)
        {
            lastKnownPlayerPosition = currentTargetPosition;
            if (distanceToPlayer <= attackRange)
            {
                SetState(AIState.Attack);
            }
            else
            {
                // Move towards player
                if (enemyType == EnemyType.ReaperDrone)
                {
                    // Drone-specific chase, maintain hover height
                    Vector3 desiredPos = new Vector3(currentTargetPosition.x, currentTargetPosition.y + droneHoverHeight, currentTargetPosition.z);
                    transform.position = Vector3.MoveTowards(transform.position, desiredPos, droneFlightSpeed * Time.deltaTime);
                }
                else
                {
                    if (navMeshAgent != null && navMeshAgent.enabled)
                    {
                        navMeshAgent.speed = chaseSpeed;
                        navMeshAgent.isStopped = false;
                        navMeshAgent.SetDestination(currentTargetPosition);
                    }
                }
            }
        }
        else if (distanceToPlayer > losePlayerDistance)
        {
            // Lost player and too far, go back to last known position or patrol
            if (navMeshAgent != null && navMeshAgent.enabled && navMeshAgent.remainingDistance < navMeshAgent.stoppingDistance + 1f && Vector3.Distance(transform.position, lastKnownPlayerPosition) < 2f)
            {
                SetState(AIState.Patrol); // Reached last known position, still no sight, go to patrol
            }
            else if (navMeshAgent != null && navMeshAgent.enabled && Vector3.Distance(transform.position, lastKnownPlayerPosition) > 2f)
            {
                navMeshAgent.speed = chaseSpeed;
                navMeshAgent.isStopped = false;
                navMeshAgent.SetDestination(lastKnownPlayerPosition);
            }
            else if (enemyType == EnemyType.ReaperDrone)
            {
                // Drones can "hover" at last known position
                Vector3 desiredPos = new Vector3(lastKnownPlayerPosition.x, lastKnownPlayerPosition.y + droneHoverHeight, lastKnownPlayerPosition.z);
                transform.position = Vector3.MoveTowards(transform.position, desiredPos, droneFlightSpeed * Time.deltaTime);
            }
        }
        else
        {
            // Player lost line of sight but still close, move towards last known position
            if (enemyType == EnemyType.ReaperDrone)
            {
                Vector3 desiredPos = new Vector3(lastKnownPlayerPosition.x, lastKnownPlayerPosition.y + droneHoverHeight, lastKnownPlayerPosition.z);
                transform.position = Vector3.MoveTowards(transform.position, desiredPos, droneFlightSpeed * Time.deltaTime);
            }
            else
            {
                if (navMeshAgent != null && navMeshAgent.enabled)
                {
                    navMeshAgent.speed = chaseSpeed;
                    navMeshAgent.isStopped = false;
                    navMeshAgent.SetDestination(lastKnownPlayerPosition);
                }
            }
        }

        RotateTowards(lastKnownPlayerPosition);
    }


    /// <summary>
    /// Handles enemy attacking behavior.
    /// </summary>
    private void AttackPlayer()
    {
        if (playerTarget == null)
        {
            SetState(AIState.Patrol);
            return;
        }

        Vector3 currentTargetPosition = playerTarget.transform.position;
        float distanceToPlayer = Vector3.Distance(transform.position, currentTargetPosition);

        // Check line of sight
        RaycastHit hit;
        Vector3 eyeLevel = transform.position + Vector3.up * playerSightClearanceHeight;
        Vector3 playerEyeLevel = currentTargetPosition + Vector3.up * playerSightClearanceHeight;

        bool hasLineOfSight = Physics.Raycast(eyeLevel, (playerEyeLevel - eyeLevel).normalized, out hit, distanceToPlayer, playerLayer | obstacleLayer) &&
                              hit.collider.gameObject == playerTarget;

        if (!hasLineOfSight || (distanceToPlayer > attackRange && enemyType != EnemyType.GhostOperative) || (enemyType == EnemyType.GhostOperative && distanceToPlayer > sniperRange))
        {
            SetState(AIState.Chase); // Lost line of sight or out of range, go back to chase
            return;
        }

        if (navMeshAgent != null && navMeshAgent.enabled && !canMoveWhileAttacking)
        {
            navMeshAgent.isStopped = true; // Stop moving to attack if not allowed
        }
        else if (navMeshAgent != null && navMeshAgent.enabled && canMoveWhileAttacking)
        {
            // Keep moving while attacking (e.g., Breacher Brute charging)
            navMeshAgent.isStopped = false;
        }

        RotateTowards(currentTargetPosition);

        if (Time.time >= lastAttackTime + attackCooldown)
        {
            lastAttackTime = Time.time;
            StartCoroutine(PerformAttackRoutine());
        }

        // Type-specific attack maneuvers
        if (enemyType == EnemyType.ReaperDrone)
        {
            HandleReaperDroneAttackManeuvers(currentTargetPosition);
        }
        else if (enemyType == EnemyType.BreacherBrute)
        {
            HandleBreacherBruteAttackManeuvers(currentTargetPosition);
        }
        else if (enemyType == EnemyType.GhostOperative)
        {
            HandleGhostOperativeAttackManeuvers(currentTargetPosition);
        }
    }

    private IEnumerator PerformAttackRoutine()
    {
        // Play attack animation (if any)
        if (animator != null)
        {
            animator.SetTrigger("Attack");
        }

        // Apply attack windup time
        yield return new WaitForSeconds(attackWindupTime);

        // Perform actual attack only if still in attack state and player is in range
        if (currentState == AIState.Attack && playerTarget != null)
        {
            if (Vector3.Distance(transform.position, playerTarget.transform.position) <= attackRange || (enemyType == EnemyType.GhostOperative && Vector3.Distance(transform.position, playerTarget.transform.position) <= sniperRange))
            {
                if (enemyWeapon != null)
                {
                    enemyWeapon.Fire(playerTarget); // EnemyWeapon handles targeting and damage
                }
                else if (enemyType == EnemyType.BreacherBrute)
                {
                    // Brute's melee attack or shotgun logic
                    BreacherBruteAttack();
                }
            }
        }
    }

    private void HandleReaperDroneAttackManeuvers(Vector3 playerPosition)
    {
        if (Time.time > lastStrafeTime + droneStrafeCooldown && !isStrafing)
        {
            StartCoroutine(DroneStrafeRoutine(playerPosition));
        }
        else if (!isStrafing)
        {
            // Hover at current position + drone hover height
            Vector3 desiredPos = new Vector3(transform.position.x, playerPosition.y + droneHoverHeight, transform.position.z);
            transform.position = Vector3.MoveTowards(transform.position, desiredPos, droneFlightSpeed * Time.deltaTime);
        }
    }

    private IEnumerator DroneStrafeRoutine(Vector3 playerPosition)
    {
        isStrafing = true;
        lastStrafeTime = Time.time;

        // Choose a random direction to strafe (left/right relative to player)
        Vector3 directionToPlayer = (playerPosition - transform.position).normalized;
        Vector3 strafeDirection = Vector3.Cross(directionToPlayer, Vector3.up);
        if (Random.value < 0.5f) strafeDirection *= -1; // Randomly choose left or right

        // Calculate target strafe position
        strafeTargetPosition = transform.position + strafeDirection * droneStrafeDistance;
        strafeTargetPosition.y = playerPosition.y + droneHoverHeight; // Maintain hover height

        float startTime = Time.time;
        float duration = droneStrafeDistance / droneStrafeSpeed;

        while (Time.time < startTime + duration && Vector3.Distance(transform.position, strafeTargetPosition) > 0.5f)
        {
            transform.position = Vector3.MoveTowards(transform.position, strafeTargetPosition, droneStrafeSpeed * Time.deltaTime);
            RotateTowards(playerPosition); // Keep looking at player
            yield return null;
        }

        isStrafing = false;
    }

    private void HandleBreacherBruteAttackManeuvers(Vector3 playerPosition)
    {
        if (Time.time > lastChargeTime + bruteChargeCooldown && !isCharging)
        {
            float distanceToPlayer = Vector3.Distance(transform.position, playerPosition);
            if (distanceToPlayer > attackRange && distanceToPlayer <= bruteChargeDistance)
            {
                StartCoroutine(BruteChargeRoutine(playerPosition));
            }
        }
        else if (!isCharging)
        {
            // If not charging, brute might just walk towards player within attack range
            if (navMeshAgent != null && navMeshAgent.enabled)
            {
                navMeshAgent.isStopped = false;
                navMeshAgent.speed = chaseSpeed; // Use chase speed for normal movement in attack state
                navMeshAgent.SetDestination(playerPosition);
            }
        }
    }

    private IEnumerator BruteChargeRoutine(Vector3 playerPosition)
    {
        isCharging = true;
        lastChargeTime = Time.time;

        if (navMeshAgent != null && navMeshAgent.enabled)
        {
            navMeshAgent.isStopped = false;
            navMeshAgent.speed = bruteChargeSpeed;
            navMeshAgent.acceleration = bruteChargeSpeed * 2; // Make charge feel faster
            chargeStartPos = transform.position;
            chargeTargetPos = playerPosition; // Charge directly at player's current position

            // Trigger charge animation
            if (animator != null) animator.SetTrigger("Charge");

            // Ensure destination is set and reachable
            if (navMeshAgent.SetDestination(chargeTargetPos))
            {
                // Wait until Brute reaches target or charge distance exceeded
                float chargeDuration = Vector3.Distance(chargeStartPos, chargeTargetPos) / bruteChargeSpeed;
                float timer = 0f;
                while (timer < chargeDuration && Vector3.Distance(transform.position, chargeTargetPos) > attackRange && currentState == AIState.Attack)
                {
                    timer += Time.deltaTime;
                    RotateTowards(playerPosition);
                    yield return null;
                }
            }
            navMeshAgent.acceleration = chaseSpeed; // Reset acceleration
        }
        isCharging = false;
    }

    private void BreacherBruteAttack()
    {
        // Implement brute's shotgun or melee attack here
        // This is separate from EnemyWeapon.Fire as brute has unique attack
        Collider[] hitColliders = Physics.OverlapSphere(transform.position + transform.forward * 1f, attackRange, playerLayer);
        foreach (var hitCol in hitColliders)
        {
            if (hitCol.CompareTag("Player"))
            {
                IDamageable playerDamageable = hitCol.GetComponent<IDamageable>();
                if (playerDamageable != null)
                {
                    // Example: Brute deals 30 damage, generic type
                    playerDamageable.TakeDamage(30f, hitCol.ClosestPoint(transform.position), DamageType.Generic, gameObject);
                }
            }
        }
    }

    private void HandleGhostOperativeAttackManeuvers(Vector3 playerPosition)
    {
        // Ghost Operative's behavior: try to cloak, find a sniper vantage point, then snipe
        if (isCloaked)
        {
            // While cloaked, if at vantage point, try to snipe
            if (sniperVantagePoint != null && Vector3.Distance(transform.position, sniperVantagePoint.position) < navMeshAgent.stoppingDistance + 1f)
            {
                // Ready to snipe. Attack routine handles the actual shot.
                // Keep looking at player
                RotateTowards(playerPosition);
            }
            else
            {
                // Move to vantage point while cloaked
                if (navMeshAgent != null && navMeshAgent.enabled && sniperVantagePoint != null)
                {
                    navMeshAgent.speed = patrolSpeed; // Move slower while cloaked
                    navMeshAgent.isStopped = false;
                    navMeshAgent.SetDestination(sniperVantagePoint.position);
                }
            }
        }
        else if (Time.time > lastCloakTime + cloakCooldown + cloakDuration) // Cooldown + duration is over
        {
            StartCoroutine(CloakRoutine());
        }
        else
        {
            // Not cloaked and on cooldown, reposition or engage normally (if in range)
            if (navMeshAgent != null && navMeshAgent.enabled)
            {
                // Maybe move to a different cover point or reposition slightly
                navMeshAgent.speed = chaseSpeed;
                navMeshAgent.isStopped = false;
                navMeshAgent.SetDestination(playerPosition); // Move a bit closer if needed
            }
        }
    }

    private IEnumerator CloakRoutine()
    {
        isCloaked = true;
        lastCloakTime = Time.time;
        if (animator != null) animator.SetTrigger("Cloak");
        // Apply cloaking effect (shader change, transparency)
        SetCloakingEffect(true);

        // Find a sniper vantage point (this would be more sophisticated in a real game)
        // For now, let's assume there's a predefined point or calculate one dynamically
        // sniperVantagePoint = FindNearestVantagePoint(playerTarget.transform.position); // Needs implementation
        if (patrolWaypoints != null && patrolWaypoints.Length > 0)
        {
            sniperVantagePoint = patrolWaypoints[Random.Range(0, patrolWaypoints.Length)];
        }
        else
        {
            // If no vantage points, just try to hide behind something
            sniperVantagePoint = transform; // No actual repositioning if no points
        }

        yield return new WaitForSeconds(cloakDuration);

        // De-cloak
        if (animator != null) animator.SetTrigger("Decloak");
        SetCloakingEffect(false);
        isCloaked = false;
    }

    private void SetCloakingEffect(bool cloaked)
    {
        if (renderers == null || renderers.Length == 0) return;

        foreach (Renderer r in renderers)
        {
            if (cloaked)
            {
                // Apply cloaked material with transparency or special shader
                if (cloakedMaterial != null)
                {
                    r.material = cloakedMaterial;
                    // Example: fade out the material's alpha
                    StartCoroutine(FadeMaterialAlpha(r.material, 1f, 0.2f, decloakDuration));
                }
            }
            else
            {
                // Restore original material
                int index = System.Array.IndexOf(renderers, r);
                if (index >= 0 && index < originalMaterials.Length)
                {
                    StartCoroutine(FadeMaterialAlpha(r.material, r.material.color.a, 1f, decloakDuration, originalMaterials[index]));
                }
            }
        }
    }

    private IEnumerator FadeMaterialAlpha(Material mat, float startAlpha, float endAlpha, float duration, Material targetMaterial = null)
    {
        float timer = 0f;
        Color color = mat.color;
        while (timer < duration)
        {
            timer += Time.deltaTime;
            color.a = Mathf.Lerp(startAlpha, endAlpha, timer / duration);
            mat.color = color;
            yield return null;
        }
        color.a = endAlpha;
        mat.color = color;

        if (!Mathf.Approximately(endAlpha, 1f) && targetMaterial != null)
        {
            // Swap back to original material once fully visible
            if (mat != null) mat = targetMaterial;
        }
    }


    /// <summary>
    /// Rotates the enemy to face a target position smoothly.
    /// </summary>
    private void RotateTowards(Vector3 targetPosition)
    {
        Vector3 direction = (targetPosition - transform.position).normalized;
        direction.y = 0; // Keep rotation horizontal
        if (direction == Vector3.zero) return;

        Quaternion lookRotation = Quaternion.LookRotation(direction);
        transform.rotation = Quaternion.Slerp(transform.rotation, lookRotation, Time.deltaTime * 5f); // Smooth rotation
    }

    /// <summary>
    /// Sets the current AI state and performs any entry actions.
    /// </summary>
    /// <param name="newState">The new AIState to transition to.</param>
    private void SetState(AIState newState)
    {
        if (currentState == newState) return;

        // Exit current state (if any specific cleanup is needed)
        switch (currentState)
        {
            case AIState.Chase:
                if (navMeshAgent != null && navMeshAgent.enabled)
                {
                    navMeshAgent.isStopped = true;
                }
                break;
            case AIState.Attack:
                if (navMeshAgent != null && navMeshAgent.enabled)
                {
                    navMeshAgent.isStopped = true;
                }
                // Stop charge/strafe routines if active
                StopAllCoroutines(); 
                isCharging = false;
                isStrafing = false;
                break;
            case AIState.Patrol:
                if (navMeshAgent != null && navMeshAgent.enabled)
                {
                    navMeshAgent.isStopped = true;
                }
                break;
            case AIState.GhostOperative:
                // Ensure decloaked
                if (isCloaked) SetCloakingEffect(false);
                break;
        }

        currentState = newState;
        // Debug.Log($"{gameObject.name} transitioned to state: {currentState}");

        // Enter new state (if any specific setup is needed)
        switch (currentState)
        {
            case AIState.Idle:
                if (navMeshAgent != null && navMeshAgent.enabled)
                {
                    navMeshAgent.isStopped = true;
                }
                break;
            case AIState.Patrol:
                if (navMeshAgent != null && navMeshAgent.enabled)
                {
                    navMeshAgent.isStopped = false;
                    if (patrolWaypoints != null && patrolWaypoints.Length > 0)
                    {
                        navMeshAgent.SetDestination(patrolWaypoints[currentWaypointIndex].position);
                    }
                }
                else if (enemyType == EnemyType.ReaperDrone)
                {
                    // Drones don't use NavMesh for patrol, they might fly a predefined path
                    // For now, they just hover if no player is found.
                }
                break;
            case AIState.Chase:
                if (enemyType != EnemyType.ReaperDrone)
                {
                    if (navMeshAgent != null && navMeshAgent.enabled)
                    {
                        navMeshAgent.isStopped = false;
                        navMeshAgent.speed = chaseSpeed;
                    }
                }
                break;
            case AIState.Attack:
                if (enemyType != EnemyType.ReaperDrone)
                {
                    if (navMeshAgent != null && navMeshAgent.enabled)
                    {
                        if (!canMoveWhileAttacking) navMeshAgent.isStopped = true;
                        else navMeshAgent.isStopped = false; // Allow movement for charging brute
                    }
                }
                break;
            case AIState.Dead:
                // Specific actions for dead state are mostly handled by EnemyHealth
                if (navMeshAgent != null && navMeshAgent.enabled)
                {
                    navMeshAgent.isStopped = true;
                    navMeshAgent.enabled = false;
                }
                StopAllCoroutines();
                break;
        }
    }

    /// <summary>
    /// Updates animator parameters based on current AI state and movement.
    /// </summary>
    private void UpdateAnimatorParameters()
    {
        if (animator == null) return;

        float speed = 0f;
        if (navMeshAgent != null && navMeshAgent.enabled)
        {
            speed = navMeshAgent.velocity.magnitude / navMeshAgent.speed;
        }
        else if (enemyType == EnemyType.ReaperDrone)
        {
            speed = (transform.position - lastKnownPlayerPosition).magnitude > 0.1f ? 1f : 0f; // Simple drone movement
        }

        animator.SetFloat("Speed", speed);
        animator.SetBool("IsChasing", currentState == AIState.Chase || currentState == AIState.Attack);
        // "Attack" trigger is set in PerformAttackRoutine
        // "Die" trigger is set in EnemyHealth
    }

    /// <summary>
    /// Disables the AI's update loop and NavMeshAgent.
    /// Called by EnemyHealth when the enemy dies.
    /// </summary>
    public void DisableAI()
    {
        aiActive = false;
        SetState(AIState.Dead); // Ensure AI state reflects dead
        if (navMeshAgent != null && navMeshAgent.enabled)
        {
            navMeshAgent.isStopped = true;
            navMeshAgent.enabled = false;
        }
        if (animator != null)
        {
            animator.enabled = false; // Stop animations
        }
        if (enemyWeapon != null)
        {
            enemyWeapon.enabled = false; // Stop weapon from firing
        }
        // If cloaked, decloak
        if (enemyType == EnemyType.GhostOperative && isCloaked)
        {
            SetCloakingEffect(false);
        }
        StopAllCoroutines();
    }

    /// <summary>
    /// Re-enables the AI's update loop and NavMeshAgent.
    /// Called by EnemyHealth when the enemy is reset (e.g., for pooling).
    /// </summary>
    public void EnableAI()
    {
        aiActive = true;
        if (navMeshAgent != null)
        {
            navMeshAgent.enabled = true;
            navMeshAgent.isStopped = false;
            // Reset speed based on enemy type
            if (enemyType == EnemyType.ReaperDrone) navMeshAgent.speed = droneFlightSpeed;
            else if (enemyType == EnemyType.BreacherBrute) navMeshAgent.speed = patrolSpeed;
            else if (enemyType == EnemyType.GhostOperative) navMeshAgent.speed = patrolSpeed;
        }
        if (animator != null)
        {
            animator.enabled = true;
            animator.Rebind(); // Reset animator state
            animator.Update(0f);
        }
        if (enemyWeapon != null)
        {
            enemyWeapon.enabled = true;
        }

        // Reset type-specific states
        if (enemyType == EnemyType.ReaperDrone)
        {
            lastStrafeTime = Time.time;
            isStrafing = false;
        }
        else if (enemyType == EnemyType.BreacherBrute)
        {
            lastChargeTime = Time.time;
            isCharging = false;
        }
        else if (enemyType == EnemyType.GhostOperative)
        {
            isCloaked = false;
            lastCloakTime = -Mathf.Infinity;
            SetCloakingEffect(false); // Ensure fully visible
        }

        // Re-evaluate initial state (patrol if waypoints, else idle)
        if (patrolWaypoints != null && patrolWaypoints.Length > 0)
        {
            SetState(AIState.Patrol);
        }
        else
        {
            SetState(AIState.Idle);
        }

        // Find player target again in case it was destroyed and respawned (or scene changed)
        playerTarget = GameObject.FindGameObjectWithTag("Player");
    }

    /// <summary>
    /// Global handler for EnemyDied event.
    /// </summary>
    /// <param name="diedEnemy">The GameObject of the enemy that died.</param>
    /// <param name="instigator">The GameObject that caused the death.</param>
    private void HandleEnemyDiedGlobally(GameObject diedEnemy, GameObject instigator)
    {
        if (diedEnemy == gameObject)
        {
            // This instance of EnemyAIController is the one that died
            OnEnemyKilled?.Invoke(gameObject, instigator);

            // Inform ObjectiveManager that this enemy has died, if it's tied to an objective.
            // This is handled by ObjectiveManager.HandleEnemyDied, so no direct call needed here.
            // But we ensure the correct tag is set on the enemy GameObject.
            // e.g., this.gameObject.CompareTag("BreacherBrute") will be used by ObjectiveManager.
        }
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, playerDetectionRadius);

        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, attackRange);

        if (currentState == AIState.Patrol && patrolWaypoints != null && patrolWaypoints.Length > 0)
        {
            Gizmos.color = Color.green;
            for (int i = 0; i < patrolWaypoints.Length; i++)
            {
                if (patrolWaypoints[i] != null)
                {
                    Gizmos.DrawSphere(patrolWaypoints[i].position, 0.5f);
                    if (i < patrolWaypoints.Length - 1)
                    {
                        Gizmos.DrawLine(patrolWaypoints[i].position, patrolWaypoints[i + 1].position);
                    }
                    else if (patrolWaypoints.Length > 1)
                    {
                        Gizmos.DrawLine(patrolWaypoints[i].position, patrolWaypoints[0].position); // Loop back
                    }
                }
            }
            if (navMeshAgent != null && navMeshAgent.enabled && navMeshAgent.hasPath)
            {
                Gizmos.color = Color.blue;
                Vector3[] pathCorners = navMeshAgent.path.corners;
                for (int i = 0; i < pathCorners.Length - 1; i++)
                {
                    Gizmos.DrawLine(pathCorners[i], pathCorners[i + 1]);
                }
            }
        }
    }
}