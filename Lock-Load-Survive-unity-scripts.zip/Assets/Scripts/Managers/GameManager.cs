using UnityEngine;
using UnityEngine.SceneManagement;
using System;
using System.Collections; // Required for Coroutines

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    public enum GameState { MainMenu, Playing, Paused, GameOver, MissionComplete }

    [SerializeField] private GameState currentGameState = GameState.MainMenu;
    public GameState CurrentGameState => currentGameState;

    // References to other managers (assigned in Inspector or via FindObjectOfType)
    private ObjectiveManager objectiveManager;
    private UIManager uiManager;
    private AudioManager audioManager;
    private SaveLoadManager saveLoadManager;
    // private SpawnManager spawnManager; // Assuming SpawnManager will be initialized by ObjectiveManager or directly in StartGame if needed

    public static event Action<GameState> OnGameStateChanged;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    private void OnEnable()
    {
        // Subscribe to events from other managers
        // PlayerHealth.OnPlayerDied is assumed to exist as per explanation
        if (PlayerHealth.Instance != null) // Check if PlayerHealth exists and is initialized
        {
            PlayerHealth.Instance.OnPlayerDied += HandlePlayerDied;
        }

        // ObjectiveManager.OnObjectiveCompleted is assumed to exist
        if (ObjectiveManager.Instance != null) // Check if ObjectiveManager exists and is initialized
        {
            ObjectiveManager.Instance.OnMissionCompleted += HandleMissionCompleted;
        }
    }

    private void OnDisable()
    {
        // Unsubscribe from events
        if (PlayerHealth.Instance != null)
        {
            PlayerHealth.Instance.OnPlayerDied -= HandlePlayerDied;
        }
        if (ObjectiveManager.Instance != null)
        {
            ObjectiveManager.Instance.OnMissionCompleted -= HandleMissionCompleted;
        }
    }

    private void Start()
    {
        // Find and assign manager references if they are not assigned in the Inspector
        objectiveManager = FindObjectOfType<ObjectiveManager>();
        if (objectiveManager == null)
        {
            Debug.LogError("GameManager: ObjectiveManager not found in scene!");
        }

        uiManager = FindObjectOfType<UIManager>();
        if (uiManager == null)
        {
            Debug.LogError("GameManager: UIManager not found in scene!");
        }

        audioManager = FindObjectOfType<AudioManager>();
        if (audioManager == null)
        {
            Debug.LogError("GameManager: AudioManager not found in scene!");
        }

        saveLoadManager = FindObjectOfType<SaveLoadManager>();
        if (saveLoadManager == null)
        {
            Debug.LogWarning("GameManager: SaveLoadManager not found in scene. Save/Load functionality might be limited.");
        }

        SetGameState(GameState.MainMenu);
    }

    public void StartGame(GameMode mode)
    {
        Debug.Log($"GameManager: Starting game in {mode} mode.");
        // Initialize ObjectiveManager and potentially SpawnManager for the new game
        if (objectiveManager != null)
        {
            objectiveManager.InitializeMissionObjectives(mode); // Assuming ObjectiveManager has this method
        }
        else
        {
            Debug.LogError("GameManager: Cannot initialize mission objectives, ObjectiveManager is null.");
        }

        // Assuming SpawnManager needs to be initialized or reset here
        // if (spawnManager != null) { spawnManager.InitializeSpawns(); }

        SetGameState(GameState.Playing);
        Time.timeScale = 1f; // Ensure game is running at normal speed
        if (audioManager != null)
        {
            audioManager.PlayMusic("GameplayMusic"); // Assuming AudioManager has PlayMusic method
        }
    }

    public void EndGame(bool playerWon)
    {
        Debug.Log($"GameManager: Game Ended. Player Won: {playerWon}");
        if (playerWon)
        {
            SetGameState(GameState.MissionComplete);
            if (uiManager != null)
            {
                uiManager.ShowGameOverScreen(true);
            }
            if (audioManager != null)
            {
                audioManager.PlaySound("MissionCompleteSound"); // Assuming AudioManager has PlaySound
            }
            if (saveLoadManager != null)
            {
                saveLoadManager.SaveGameData(); // Assuming SaveGameData handles player progress
            }
        }
        else
        {
            SetGameState(GameState.GameOver);
            if (uiManager != null)
            {
                uiManager.ShowGameOverScreen(false);
            }
            if (audioManager != null)
            {
                audioManager.PlaySound("GameOverSound");
            }
        }
        Time.timeScale = 0f; // Pause game logic on game over
    }

    public void PauseGame()
    {
        if (currentGameState == GameState.Playing)
        {
            Debug.Log("GameManager: Game Paused.");
            SetGameState(GameState.Paused);
            Time.timeScale = 0f; // Pause game logic
            if (uiManager != null)
            {
                uiManager.ShowPauseMenu(); // Assuming UIManager has ShowPauseMenu
            }
            if (audioManager != null)
            {
                audioManager.PauseAllSounds(); // Assuming AudioManager has PauseAllSounds
            }
        }
    }

    public void ResumeGame()
    {
        if (currentGameState == GameState.Paused)
        {
            Debug.Log("GameManager: Game Resumed.");
            SetGameState(GameState.Playing);
            Time.timeScale = 1f; // Resume game logic
            if (uiManager != null)
            {
                uiManager.HidePauseMenu(); // Assuming UIManager has HidePauseMenu
            }
            if (audioManager != null)
            {
                audioManager.ResumeAllSounds(); // Assuming AudioManager has ResumeAllSounds
            }
        }
    }

    public void LoadLevel(string levelName)
    {
        Debug.Log($"GameManager: Loading level: {levelName}");
        SetGameState(GameState.Paused); // Briefly pause game state during loading
        Time.timeScale = 0f; // Freeze game
        StartCoroutine(LoadLevelAsync(levelName));
    }

    private IEnumerator LoadLevelAsync(string levelName)
    {
        AsyncOperation asyncLoad = SceneManager.LoadSceneAsync(levelName);

        while (!asyncLoad.isDone)
        {
            // You can update a loading bar here using asyncLoad.progress
            yield return null;
        }

        // After scene loaded, re-establish references if needed, or if Managers are DontDestroyOnLoad, they will persist
        objectiveManager = FindObjectOfType<ObjectiveManager>();
        uiManager = FindObjectOfType<UIManager>();
        audioManager = FindObjectOfType<AudioManager>();
        saveLoadManager = FindObjectOfType<SaveLoadManager>();

        SetGameState(GameState.Playing); // Set to playing after level is fully loaded
        Time.timeScale = 1f; // Resume game
        Debug.Log($"GameManager: Level {levelName} loaded successfully.");
    }

    private void SetGameState(GameState newState)
    {
        if (currentGameState == newState) return;

        currentGameState = newState;
        Debug.Log($"GameManager: GameState changed to {currentGameState}");
        OnGameStateChanged?.Invoke(currentGameState);
    }

    private void HandlePlayerDied()
    {
        Debug.Log("GameManager: Player died event received.");
        if (currentGameState == GameState.Playing)
        {
            EndGame(false); // Player lost
        }
    }

    private void HandleMissionCompleted()
    {
        Debug.Log("GameManager: Mission completed event received.");
        if (currentGameState == GameState.Playing)
        {
            EndGame(true); // Player won
        }
    }

    // Optional: Method to transition to Main Menu
    public void GoToMainMenu()
    {
        Debug.Log("GameManager: Transitioning to Main Menu.");
        Time.timeScale = 1f; // Ensure normal time scale for main menu animations/interactions
        SetGameState(GameState.MainMenu);
        SceneManager.LoadScene("MainMenu"); // Assuming "MainMenu" is the name of your main menu scene
        if (audioManager != null)
        {
            audioManager.PlayMusic("MainMenuMusic"); // Assuming AudioManager has a main menu music track
            audioManager.ResumeAllSounds(); // In case it was paused
        }
    }
}