// Required Packages:
// - com.unity.inputsystem

using UnityEngine;
using UnityEngine.InputSystem;
using System;

public class InputManager : MonoBehaviour
{
    // Static events for other systems to subscribe to
    public static event Action<Vector2> OnMoveInput;
    public static event Action<Vector2> OnLookInput;
    public static event Action OnFireAction;
    public static event Action OnReloadAction;
    public static event Action OnAbility1Action;
    public static event Action OnAbility2Action;
    public static event Action OnPauseAction; // For pausing the game

    private static InputManager _instance;

    public static InputManager Instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = FindObjectOfType<InputManager>();
                if (_instance == null)
                {
                    GameObject singletonObject = new GameObject(typeof(InputManager).Name);
                    _instance = singletonObject.AddComponent<InputManager>();
                    DontDestroyOnLoad(singletonObject);
                }
            }
            return _instance;
        }
    }

    private PlayerInput _playerInput;

    private void Awake()
    {
        if (_instance != null && _instance != this)
        {
            Destroy(gameObject);
            return;
        }
        _instance = this;
        DontDestroyOnLoad(gameObject);

        _playerInput = GetComponent<PlayerInput>();
        if (_playerInput == null)
        {
            Debug.LogError("InputManager requires a PlayerInput component on the same GameObject.", this);
            enabled = false;
        }
    }

    // Input System callback for 'Move' action
    private void OnMove(InputValue value)
    {
        OnMoveInput?.Invoke(value.Get<Vector2>());
    }

    // Input System callback for 'Look' action
    private void OnLook(InputValue value)
    {
        OnLookInput?.Invoke(value.Get<Vector2>());
    }

    // Input System callback for 'Fire' action
    private void OnFire(InputValue value)
    {
        if (value.isPressed) // Trigger only on button press for typical firing
        {
            OnFireAction?.Invoke();
        }
    }

    // Input System callback for 'Reload' action
    private void OnReload(InputValue value)
    {
        if (value.isPressed)
        {
            OnReloadAction?.Invoke();
        }
    }

    // Input System callback for 'Ability1' action
    private void OnAbility1(InputValue value)
    {
        if (value.isPressed)
        {
            OnAbility1Action?.Invoke();
        }
    }

    // Input System callback for 'Ability2' action
    private void OnAbility2(InputValue value)
    {
        if (value.isPressed)
        {
            OnAbility2Action?.Invoke();
        }
    }

    // Input System callback for 'Pause' action
    private void OnPause(InputValue value)
    {
        if (value.isPressed)
        {
            OnPauseAction?.Invoke();
        }
    }
}