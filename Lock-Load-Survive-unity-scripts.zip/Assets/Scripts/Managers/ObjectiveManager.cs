using UnityEngine;
using System;
using System.Collections.Generic;
using System.Linq;

public class ObjectiveManager : MonoBehaviour
{
    public static ObjectiveManager Instance { get; private set; }

    // Event for UI updates when an objective's progress changes
    public static event Action<string, int, int, bool> OnObjectiveProgressChanged; // objectiveID, currentProgress, targetProgress, isCompleted
    // Event for UI updates and GameManager when an objective is completed
    public static event Action<string> OnObjectiveCompleted; // objectiveID
    // Event for GameManager when all objectives in a mission are completed
    public static event Action OnMissionCompleted;

    private Dictionary<string, ObjectiveData> activeObjectives = new Dictionary<string, ObjectiveData>();

    [System.Serializable]
    public class ObjectiveData
    {
        public string ID;
        public string Description;
        public int CurrentProgress;
        public int TargetProgress;
        public bool IsCompleted;
        public ObjectiveType Type;
        public string TargetEnemyTag; // For 'KillXEnemies' type
        public string TargetAreaTag;  // For 'ReachArea' type

        public enum ObjectiveType
        {
            KillXEnemies,
            ReachArea,
            CollectItems, // Example of another type
            DestroyTarget // Example of another type
        }

        public ObjectiveData(string id, string description, int targetProgress, ObjectiveType type, string targetTag = "")
        {
            ID = id;
            Description = description;
            CurrentProgress = 0;
            TargetProgress = targetProgress;
            IsCompleted = false;
            Type = type;

            if (type == ObjectiveType.KillXEnemies)
            {
                TargetEnemyTag = targetTag;
            }
            else if (type == ObjectiveType.ReachArea)
            {
                TargetAreaTag = targetTag;
            }
        }

        public void IncrementProgress(int amount = 1)
        {
            if (IsCompleted) return;

            CurrentProgress = Mathf.Min(CurrentProgress + amount, TargetProgress);
            if (CurrentProgress >= TargetProgress)
            {
                IsCompleted = true;
            }
        }

        public void SetProgress(int progress)
        {
            if (IsCompleted) return;

            CurrentProgress = Mathf.Min(progress, TargetProgress);
            if (CurrentProgress >= TargetProgress)
            {
                IsCompleted = true;
            }
        }
    }

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        // Don't destroy on load might be useful if the manager persists across scenes and re-initializes objectives per mission
        // DontDestroyOnLoad(gameObject); 
    }

    private void OnEnable()
    {
        // Subscribe to relevant events from other systems
        EnemyHealth.OnEnemyDied += HandleEnemyDied;
        TriggerZone.OnPlayerEnteredTriggerZone += HandlePlayerEnteredTriggerZone;
    }

    private void OnDisable()
    {
        // Unsubscribe from events to prevent memory leaks
        EnemyHealth.OnEnemyDied -= HandleEnemyDied;
        TriggerZone.OnPlayerEnteredTriggerZone -= HandlePlayerEnteredTriggerZone;
    }

    /// <summary>
    /// Initializes mission objectives based on the current game mode.
    /// This method is called by GameManager.
    /// </summary>
    /// <param name="mode">The current GameMode, used to determine which objectives to set up.</param>
    public void InitializeMissionObjectives(GameManager.GameMode mode)
    {
        activeObjectives.Clear();
        // Here you would typically load objectives from a configuration, ScriptableObject, or level data
        Debug.Log($"ObjectiveManager: Initializing objectives for GameMode: {mode}");

        if (mode == GameManager.GameMode.SinglePlayerCampaign)
        {
            // Example objectives for a single-player mission
            RegisterObjective(new ObjectiveData("OBJ_KILL_BRUTES_01", "Eliminate 5 Breacher Brutes", 5, ObjectiveData.ObjectiveType.KillXEnemies, "BreacherBrute"));
            RegisterObjective(new ObjectiveData("OBJ_REACH_SAFEZONE_01", "Reach the extraction point", 1, ObjectiveData.ObjectiveType.ReachArea, "ExtractionZone"));
            RegisterObjective(new ObjectiveData("OBJ_KILL_DRONES_01", "Destroy 3 Reaper Drones", 3, ObjectiveData.ObjectiveType.KillXEnemies, "ReaperDrone"));
        }
        else if (mode == GameManager.GameMode.MultiplayerTeamDeathmatch)
        {
            // Example objectives for multiplayer (e.g., score X points, control Y zones)
            RegisterObjective(new ObjectiveData("MP_SCORE_TARGET", "Reach 50 kills", 50, ObjectiveData.ObjectiveType.CollectItems, "PlayerScore"));
        }
        // ... add more modes as needed

        if (activeObjectives.Count == 0)
        {
            Debug.LogWarning("ObjectiveManager: No objectives registered for the current game mode. Mission might not progress.");
        }
    }

    /// <summary>
    /// Registers a new objective with the manager.
    /// </summary>
    /// <param name="objective">The ObjectiveData object to register.</param>
    public void RegisterObjective(ObjectiveData objective)
    {
        if (string.IsNullOrEmpty(objective.ID))
        {
            Debug.LogError("ObjectiveManager: Attempted to register an objective with an empty ID.");
            return;
        }

        if (activeObjectives.ContainsKey(objective.ID))
        {
            Debug.LogWarning($"ObjectiveManager: Objective with ID '{objective.ID}' already registered. Overwriting.");
            activeObjectives[objective.ID] = objective;
        }
        else
        {
            activeObjectives.Add(objective.ID, objective);
        }

        OnObjectiveProgressChanged?.Invoke(objective.ID, objective.CurrentProgress, objective.TargetProgress, objective.IsCompleted);
        Debug.Log($"ObjectiveManager: Registered objective: {objective.ID} - {objective.Description}");
    }

    /// <summary>
    /// Updates the progress of a specific objective.
    /// If the progress changes or completes, relevant events are triggered.
    /// </summary>
    /// <param name="objectiveID">The unique ID of the objective.</param>
    /// <param name="amount">The amount to increment progress by (default is 1).</param>
    public void UpdateObjectiveProgress(string objectiveID, int amount = 1)
    {
        if (activeObjectives.TryGetValue(objectiveID, out ObjectiveData objective))
        {
            if (objective.IsCompleted) return;

            int previousProgress = objective.CurrentProgress;
            objective.IncrementProgress(amount);

            if (objective.CurrentProgress != previousProgress)
            {
                Debug.Log($"ObjectiveManager: Objective '{objective.ID}' progress updated: {objective.CurrentProgress}/{objective.TargetProgress}");
                OnObjectiveProgressChanged?.Invoke(objective.ID, objective.CurrentProgress, objective.TargetProgress, objective.IsCompleted);

                if (objective.IsCompleted)
                {
                    CompleteObjective(objectiveID);
                }
            }
        }
        else
        {
            Debug.LogWarning($"ObjectiveManager: Attempted to update progress for unknown objective ID: {objectiveID}");
        }
    }

    /// <summary>
    /// Manually sets the progress of a specific objective.
    /// If the progress changes or completes, relevant events are triggered.
    /// </summary>
    /// <param name="objectiveID">The unique ID of the objective.</param>
    /// <param name="progress">The new progress value.</param>
    public void SetObjectiveProgress(string objectiveID, int progress)
    {
        if (activeObjectives.TryGetValue(objectiveID, out ObjectiveData objective))
        {
            if (objective.IsCompleted) return;

            int previousProgress = objective.CurrentProgress;
            objective.SetProgress(progress);

            if (objective.CurrentProgress != previousProgress)
            {
                Debug.Log($"ObjectiveManager: Objective '{objective.ID}' progress set to: {objective.CurrentProgress}/{objective.TargetProgress}");
                OnObjectiveProgressChanged?.Invoke(objective.ID, objective.CurrentProgress, objective.TargetProgress, objective.IsCompleted);

                if (objective.IsCompleted)
                {
                    CompleteObjective(objectiveID);
                }
            }
        }
        else
        {
            Debug.LogWarning($"ObjectiveManager: Attempted to set progress for unknown objective ID: {objectiveID}");
        }
    }

    /// <summary>
    /// Marks an objective as completed and triggers the completion event.
    /// Called internally when an objective's progress reaches its target, or externally for instant completion.
    /// </summary>
    /// <param name="objectiveID">The unique ID of the objective to complete.</param>
    public void CompleteObjective(string objectiveID)
    {
        if (activeObjectives.TryGetValue(objectiveID, out ObjectiveData objective))
        {
            if (!objective.IsCompleted)
            {
                objective.IsCompleted = true;
                objective.CurrentProgress = objective.TargetProgress; // Ensure progress is at target

                Debug.Log($"ObjectiveManager: Objective '{objective.ID}' - '{objective.Description}' completed!");
                OnObjectiveProgressChanged?.Invoke(objective.ID, objective.CurrentProgress, objective.TargetProgress, objective.IsCompleted);
                OnObjectiveCompleted?.Invoke(objective.ID);
                CheckForMissionCompletion();
            }
        }
        else
        {
            Debug.LogWarning($"ObjectiveManager: Attempted to complete unknown objective ID: {objectiveID}");
        }
    }

    /// <summary>
    /// Checks if a specific objective is currently active (registered and not completed).
    /// </summary>
    /// <param name="objectiveID">The unique ID of the objective.</param>
    /// <returns>True if the objective is active, false otherwise.</returns>
    public bool IsObjectiveActive(string objectiveID)
    {
        if (activeObjectives.TryGetValue(objectiveID, out ObjectiveData objective))
        {
            return !objective.IsCompleted;
        }
        return false;
    }

    /// <summary>
    /// Retrieves an ObjectiveData object by its ID.
    /// </summary>
    /// <param name="objectiveID">The unique ID of the objective.</param>
    /// <returns>The ObjectiveData if found, otherwise null.</returns>
    public ObjectiveData GetObjective(string objectiveID)
    {
        activeObjectives.TryGetValue(objectiveID, out ObjectiveData objective);
        return objective;
    }

    /// <summary>
    /// Returns a read-only list of all currently active objectives.
    /// </summary>
    public IReadOnlyList<ObjectiveData> GetAllActiveObjectives()
    {
        return activeObjectives.Values.ToList().AsReadOnly();
    }

    /// <summary>
    /// Handler for when an enemy dies. Checks if any active objectives are of type 'KillXEnemies'
    /// and match the killed enemy's tag.
    /// </summary>
    /// <param name="diedEnemy">The GameObject of the enemy that died.</param>
    /// <param name="instigator">The GameObject that caused the enemy's death.</param>
    private void HandleEnemyDied(GameObject diedEnemy, GameObject instigator)
    {
        foreach (var kvp in activeObjectives)
        {
            ObjectiveData objective = kvp.Value;
            if (objective.Type == ObjectiveData.ObjectiveType.KillXEnemies && !objective.IsCompleted)
            {
                // Assuming enemies have tags like "BreacherBrute" or "ReaperDrone"
                if (!string.IsNullOrEmpty(objective.TargetEnemyTag) && diedEnemy.CompareTag(objective.TargetEnemyTag))
                {
                    UpdateObjectiveProgress(objective.ID);
                }
            }
        }
    }

    /// <summary>
    /// Handler for when the player enters a trigger zone. Checks if any active objectives are of type 'ReachArea'
    /// and match the trigger zone's tag.
    /// </summary>
    /// <param name="triggerZoneTag">The tag of the TriggerZone that was entered.</param>
    private void HandlePlayerEnteredTriggerZone(string triggerZoneTag)
    {
        foreach (var kvp in activeObjectives)
        {
            ObjectiveData objective = kvp.Value;
            if (objective.Type == ObjectiveData.ObjectiveType.ReachArea && !objective.IsCompleted)
            {
                // Assuming TriggerZone reports its tag
                if (!string.IsNullOrEmpty(objective.TargetAreaTag) && objective.TargetAreaTag.Equals(triggerZoneTag, StringComparison.OrdinalIgnoreCase))
                {
                    UpdateObjectiveProgress(objective.ID);
                }
            }
        }
    }

    /// <summary>
    /// Checks if all registered objectives are completed. If so, triggers the OnMissionCompleted event.
    /// </summary>
    private void CheckForMissionCompletion()
    {
        if (activeObjectives.Count == 0) return; // No objectives to complete

        bool allCompleted = activeObjectives.Values.All(obj => obj.IsCompleted);

        if (allCompleted)
        {
            Debug.Log("ObjectiveManager: All mission objectives completed! Triggering OnMissionCompleted.");
            OnMissionCompleted?.Invoke();
        }
    }
}

/// <summary>
/// This class represents a trigger zone in the game world.
/// When the player enters it, it notifies the ObjectiveManager.
/// </summary>
public class TriggerZone : MonoBehaviour
{
    // Event for ObjectiveManager to subscribe to
    public static event Action<string> OnPlayerEnteredTriggerZone;

    [Tooltip("A unique identifier for this trigger zone, e.g., 'ExtractionZone', 'SafeHouse'.")]
    public string triggerZoneTag;

    private void OnTriggerEnter(Collider other)
    {
        // Assuming player character has the tag "Player"
        if (other.CompareTag("Player"))
        {
            Debug.Log($"TriggerZone '{triggerZoneTag}' entered by Player.");
            OnPlayerEnteredTriggerZone?.Invoke(triggerZoneTag);
            // Optionally, deactivate the trigger zone after one use
            // gameObject.SetActive(false); 
        }
    }
}


// Dummy class for PlayerHealth for GameManager dependency
public class PlayerHealth : MonoBehaviour
{
    public static PlayerHealth Instance { get; private set; }
    public event Action OnPlayerDied;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
    }

    public void Die()
    {
        Debug.Log("Player Died (Dummy)");
        OnPlayerDied?.Invoke();
    }
}

// Dummy class for UIManager for EnemyHealth and GameManager dependency
public class UIManager : MonoBehaviour
{
    public static UIManager Instance { get; private set; }

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
    }

    public void ShowDamageIndicator(float amount, Vector3 hitPoint, DamageType damageType)
    {
        // Dummy implementation
        // Debug.Log($"UI: Show damage indicator for {amount} at {hitPoint} ({damageType})");
    }

    public void ShowGameOverScreen(bool playerWon)
    {
        Debug.Log($"UI: Showing Game Over Screen. Player Won: {playerWon}");
    }

    public void ShowPauseMenu()
    {
        Debug.Log("UI: Showing Pause Menu.");
    }

    public void HidePauseMenu()
    {
        Debug.Log("UI: Hiding Pause Menu.");
    }

    // This method is not in the UIManager overview, but added for ObjectiveManager's subscription.
    // In a real UIManager, this would update UI elements showing objective descriptions and progress.
    public void UpdateObjectiveDisplay(string objectiveID, int currentProgress, int targetProgress, bool isCompleted)
    {
        // Example of how UIManager might handle this event
        // GameObject objectiveUI = GetObjectiveUIElement(objectiveID);
        // if (objectiveUI != null)
        // {
        //      objectiveUI.GetComponent<Text>().text = $"{objectiveID}: {currentProgress}/{targetProgress}";
        //      objectiveUI.SetActive(!isCompleted); // Hide completed objectives or mark them
        // }
        // Debug.Log($"UI: Updating objective '{objectiveID}': {currentProgress}/{targetProgress} (Completed: {isCompleted})");
    }
}

// Dummy class for ParticleEffectManager for EnemyHealth dependency
public class ParticleEffectManager : MonoBehaviour
{
    public static ParticleEffectManager Instance { get; private set; }

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
    }

    public void SpawnEffect(GameObject effectPrefab, Vector3 position, Quaternion rotation, float duration)
    {
        if (effectPrefab != null)
        {
            // Debug.Log($"Spawning effect '{effectPrefab.name}' at {position}");
            // In a real scenario, this would instantiate the prefab and manage its lifecycle,
            // possibly using an object pool.
            // GameObject instance = Instantiate(effectPrefab, position, rotation);
            // Destroy(instance, duration);
        }
    }
}

// Dummy class for AudioManager for GameManager dependency
public class AudioManager : MonoBehaviour
{
    public void PlayMusic(string trackName) { /* Debug.Log($"Playing music: {trackName}"); */ }
    public void PlaySound(string soundName) { /* Debug.Log($"Playing sound: {soundName}"); */ }
    public void PauseAllSounds() { /* Debug.Log("Pausing all sounds."); */ }
    public void ResumeAllSounds() { /* Debug.Log("Resuming all sounds."); */ }
}

// Dummy class for SaveLoadManager for GameManager dependency
public class SaveLoadManager : MonoBehaviour
{
    public void SaveGameData() { /* Debug.Log("Saving game data."); */ }
    public void LoadGameData() { /* Debug.Log("Loading game data."); */ }
}

// Dummy Enum for DamageType used by EnemyHealth
public enum DamageType
{
    Generic,
    Headshot,
    Explosive,
    Melee
}

// Dummy class for EnemyAIController for EnemyHealth dependency
public class EnemyAIController : MonoBehaviour
{
    public void DisableAI()
    {
        // Debug.Log($"{gameObject.name} AI Disabled.");
        // Implement logic to stop AI movement, attacks, etc.
        enabled = false; 
    }

    public void EnableAI()
    {
        // Debug.Log($"{gameObject.name} AI Enabled.");
        // Implement logic to re-enable AI movement, attacks, etc.
        enabled = true;
    }
}