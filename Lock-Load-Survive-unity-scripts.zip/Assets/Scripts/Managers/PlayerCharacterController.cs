// Required Packages:
// - com.unity.inputsystem

using UnityEngine;
using UnityEngine.InputSystem;
using System;

public class PlayerCharacterController : MonoBehaviour
{
    [SerializeField] private float moveSpeed = 5f;
    [SerializeField] private float rotationSpeed = 720f; // Degrees per second
    [SerializeField] private float gravity = -9.81f;
    [SerializeField] private Transform cameraFollowTarget; // The transform the camera should follow/pivot around

    private CharacterController _characterController;
    private Vector3 _playerVelocity;
    private Vector2 _currentMoveInput;
    private Vector2 _currentLookInput;
    private bool _isGrounded;

    // Events for other systems to subscribe to
    public static event Action<Vector2> OnPlayerMoveInput;
    public static event Action<Vector2> OnPlayerLookInput;
    public static event Action OnPlayerFireInput;
    public static event Action OnPlayerReloadInput;
    public static event Action<int> OnPlayerAbilityActivation;
    public static event Action OnPlayerSwitchWeapon1;
    public static event Action OnPlayerSwitchWeapon2;
    public static event Action OnPlayerSwitchWeapon3;

    private void Awake()
    {
        _characterController = GetComponent<CharacterController>();
        if (_characterController == null)
        {
            Debug.LogError("PlayerCharacterController requires a CharacterController component.", this);
            enabled = false;
        }

        if (cameraFollowTarget == null)
        {
            Debug.LogWarning("Camera Follow Target not set for PlayerCharacterController. CameraManager might not function correctly.", this);
        }
    }

    private void OnEnable()
    {
        InputManager.OnMoveInput += HandleMovementInput;
        InputManager.OnLookInput += HandleLookInput;
        InputManager.OnFireAction += HandleFireAction;
        InputManager.OnReloadAction += HandleReloadAction;
        InputManager.OnAbility1Action += HandleAbility1Action;
        InputManager.OnAbility2Action += HandleAbility2Action;
        InputManager.OnSwitchWeapon1Action += HandleSwitchWeapon1;
        InputManager.OnSwitchWeapon2Action += HandleSwitchWeapon2;
        InputManager.OnSwitchWeapon3Action += HandleSwitchWeapon3;
    }

    private void OnDisable()
    {
        InputManager.OnMoveInput -= HandleMovementInput;
        InputManager.OnLookInput -= HandleLookInput;
        InputManager.OnFireAction -= HandleFireAction;
        InputManager.OnReloadAction -= HandleReloadAction;
        InputManager.OnAbility1Action -= HandleAbility1Action;
        InputManager.OnAbility2Action -= HandleAbility2Action;
        InputManager.OnSwitchWeapon1Action -= HandleSwitchWeapon1;
        InputManager.OnSwitchWeapon2Action -= HandleSwitchWeapon2;
        InputManager.OnSwitchWeapon3Action -= HandleSwitchWeapon3;
    }

    private void FixedUpdate()
    {
        _isGrounded = _characterController.isGrounded;
        if (_isGrounded && _playerVelocity.y < 0)
        {
            _playerVelocity.y = 0f;
        }

        ApplyGravity();
        HandleMovement(_currentMoveInput);
    }

    private void Update()
    {
        HandleAiming(_currentLookInput);
    }

    private void ApplyGravity()
    {
        _playerVelocity.y += gravity * Time.fixedDeltaTime;
    }

    public void HandleMovement(Vector2 input)
    {
        Vector3 moveDirection = transform.right * input.x + transform.forward * input.y;
        _characterController.Move((moveDirection * moveSpeed + _playerVelocity) * Time.fixedDeltaTime);
    }

    public void HandleAiming(Vector2 input)
    {
        if (input.sqrMagnitude > 0.01f)
        {
            float lookSpeed = rotationSpeed * Time.deltaTime;

            transform.Rotate(Vector3.up, input.x * lookSpeed);

            if (cameraFollowTarget != null)
            {
                cameraFollowTarget.Rotate(Vector3.left, input.y * lookSpeed, Space.Self);
            }
        }
    }

    public void ActivateAbility(int abilityIndex)
    {
        OnPlayerAbilityActivation?.Invoke(abilityIndex);
    }

    private void HandleMovementInput(Vector2 input)
    {
        _currentMoveInput = input;
        OnPlayerMoveInput?.Invoke(input);
    }

    private void HandleLookInput(Vector2 input)
    {
        _currentLookInput = input;
        OnPlayerLookInput?.Invoke(input);
    }

    private void HandleFireAction()
    {
        OnPlayerFireInput?.Invoke();
    }

    private void HandleReloadAction()
    {
        OnPlayerReloadInput?.Invoke();
    }

    private void HandleAbility1Action()
    {
        ActivateAbility(0);
    }

    private void HandleAbility2Action()
    {
        ActivateAbility(1);
    }

    private void HandleSwitchWeapon1()
    {
        OnPlayerSwitchWeapon1?.Invoke();
    }

    private void HandleSwitchWeapon2()
    {
        OnPlayerSwitchWeapon2?.Invoke();
    }

    private void HandleSwitchWeapon3()
    {
        OnPlayerSwitchWeapon3?.Invoke();
    }
}