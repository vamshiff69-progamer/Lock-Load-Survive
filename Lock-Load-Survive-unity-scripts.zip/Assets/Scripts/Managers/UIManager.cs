// Required Packages:
// - com.unity.textmeshpro

using UnityEngine;
using TMPro;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI; // Added for Image

public class UIManager : MonoBehaviour
{
    public static UIManager Instance { get; private set; }

    [Header("HUD Elements")]
    [SerializeField] private SliderFader playerHealthBar;
    [SerializeField] private TextMeshProUGUI ammoText;
    [SerializeField] private TextMeshProUGUI currentWeaponNameText;
    [SerializeField] private GameObject crosshair;
    [SerializeField] private GameObject hitmarker;
    [SerializeField] private float hitmarkerDisplayDuration = 0.1f;

    [Header("Ability UI")]
    [SerializeField] private List<AbilityUIElement> abilityUIElements;

    [Serializable]
    public class AbilityUIElement
    {
        public string abilityID;
        public GameObject abilityIconContainer;
        public Image abilityIcon;
        public Image cooldownOverlay;
        public TextMeshProUGUI cooldownText;
    }

    [Header("Objective Display")]
    [SerializeField] private Transform objectivePanelParent;
    [SerializeField] private GameObject objectiveUIPrefab;
    private Dictionary<string, ObjectiveUIItem> activeObjectiveUIs = new Dictionary<string, ObjectiveUIItem>();

    [Header("Panel References")]
    [SerializeField] private GameObject hudPanel;
    [SerializeField] private GameObject pauseMenuPanel;
    [SerializeField] private GameObject gameOverPanel;
    [SerializeField] private TextMeshProUGUI gameOverMessageText;

    private Coroutine _hitmarkerCoroutine;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject);

        if (playerHealthBar == null) Debug.LogError("UIManager: Player Health Bar (SliderFader) not assigned.");
        if (ammoText == null) Debug.LogError("UIManager: Ammo Text (TextMeshProUGUI) not assigned.");
        if (currentWeaponNameText == null) Debug.LogError("UIManager: Current Weapon Name Text (TextMeshProUGUI) not assigned.");
        if (crosshair == null) Debug.LogError("UIManager: Crosshair (GameObject) not assigned.");
        if (hitmarker == null) Debug.LogError("UIManager: Hitmarker (GameObject) not assigned."); else hitmarker.SetActive(false);
        if (objectivePanelParent == null) Debug.LogError("UIManager: Objective Panel Parent not assigned.");
        if (objectiveUIPrefab == null) Debug.LogError("UIManager: Objective UI Prefab not assigned.");
        if (hudPanel == null) Debug.LogError("UIManager: HUD Panel not assigned.");
        if (pauseMenuPanel == null) Debug.LogError("UIManager: Pause Menu Panel not assigned.");
        if (gameOverPanel == null) Debug.LogError("UIManager: Game Over Panel not assigned.");
        if (gameOverMessageText == null) Debug.LogError("UIManager: Game Over Message Text not assigned.");

        hudPanel?.SetActive(true);
        pauseMenuPanel?.SetActive(false);
        gameOverPanel?.SetActive(false);
    }

    private void OnEnable()
    {
        if (PlayerHealth.Instance != null)
        {
            PlayerHealth.Instance.OnHealthChanged += UpdateHealthDisplay;
        }
        else
        {
            Debug.LogWarning("UIManager: PlayerHealth instance not found. Health display will not update.");
        }

        PlayerCombatHandler.OnAmmoChanged += UpdateAmmoDisplay;
        GameManager.OnGameStateChanged += HandleGameStateChanged;
        ObjectiveManager.OnObjectiveProgressChanged += UpdateObjectiveProgress;
        CharacterAbilityManager.OnAbilityCooldownChanged += UpdateAbilityCooldown;
    }

    private void OnDisable()
    {
        if (PlayerHealth.Instance != null)
        {
            PlayerHealth.Instance.OnHealthChanged -= UpdateHealthDisplay;
        }

        PlayerCombatHandler.OnAmmoChanged -= UpdateAmmoDisplay;
        GameManager.OnGameStateChanged -= HandleGameStateChanged;
        ObjectiveManager.OnObjectiveProgressChanged -= UpdateObjectiveProgress;
        CharacterAbilityManager.OnAbilityCooldownChanged -= UpdateAbilityCooldown;
    }

    public void UpdateHealthDisplay(float currentHealth, float maxHealth)
    {
        if (playerHealthBar != null)
        {
            playerHealthBar.SetFillAmount(currentHealth / maxHealth);
        }
    }

    public void UpdateAmmoDisplay(int currentAmmo, int maxClipAmmo)
    {
        if (ammoText != null)
        {
            ammoText.text = $"{currentAmmo}/{maxClipAmmo}";
        }
    }

    public void ShowGameOverScreen(bool playerWon)
    {
        hudPanel?.SetActive(false);
        pauseMenuPanel?.SetActive(false);
        gameOverPanel?.SetActive(true);

        if (gameOverMessageText != null)
        {
            gameOverMessageText.text = playerWon ? "MISSION ACCOMPLISHED!" : "MISSION FAILED!";
        }
        else
        {
            Debug.LogWarning("UIManager: gameOverMessageText is null. Cannot display game over message.");
        }
    }

    public void ShowPauseMenu()
    {
        hudPanel?.SetActive(false);
        pauseMenuPanel?.SetActive(true);
        gameOverPanel?.SetActive(false);
    }

    public void HidePauseMenu()
    {
        hudPanel?.SetActive(true);
        pauseMenuPanel?.SetActive(false);
        gameOverPanel?.SetActive(false);
    }

    public void UpdateObjectiveProgress(string objectiveID, int currentProgress, int targetProgress, bool isCompleted)
    {
        if (objectivePanelParent == null || objectiveUIPrefab == null)
        {
            Debug.LogWarning("UIManager: Objective UI parent or prefab not assigned. Cannot display objectives.");
            return;
        }

        if (!activeObjectiveUIs.ContainsKey(objectiveID))
        {
            GameObject objUI = Instantiate(objectiveUIPrefab, objectivePanelParent);
            ObjectiveUIItem uiItem = objUI.GetComponent<ObjectiveUIItem>();
            if (uiItem == null)
            {
                Debug.LogError($"UIManager: Objective UI Prefab '{objectiveUIPrefab.name}' is missing ObjectiveUIItem component.");
                Destroy(objUI);
                return;
            }
            uiItem.Initialize(objectiveID, "Loading Description...");
            activeObjectiveUIs.Add(objectiveID, uiItem);
        }

        ObjectiveUIItem item = activeObjectiveUIs[objectiveID];
        ObjectiveManager.ObjectiveData data = ObjectiveManager.Instance?.GetObjective(objectiveID);
        if (data != null)
        {
            item.UpdateObjectiveDisplay(data.Description, currentProgress, targetProgress, isCompleted);
        }
        else
        {
            item.UpdateObjectiveDisplay($"Unknown Objective ({objectiveID})", currentProgress, targetProgress, isCompleted);
        }

        if (isCompleted)
        {
        }
    }

    public void ShowHitmarker()
    {
        if (hitmarker == null) return;

        if (_hitmarkerCoroutine != null)
        {
            StopCoroutine(_hitmarkerCoroutine);
        }
        _hitmarkerCoroutine = StartCoroutine(HitmarkerDisplayRoutine());
    }

    private IEnumerator HitmarkerDisplayRoutine()
    {
        hitmarker.SetActive(true);
        yield return new WaitForSeconds(hitmarkerDisplayDuration);
        hitmarker.SetActive(false);
    }

    public void UpdateAbilityCooldown(string abilityID, float currentCooldown, float maxCooldown)
    {
        foreach (var element in abilityUIElements)
        {
            if (element.abilityID == abilityID)
            {
                if (element.cooldownOverlay != null)
                {
                    element.cooldownOverlay.fillAmount = currentCooldown / maxCooldown;
                }
                if (element.cooldownText != null)
                {
                    element.cooldownText.text = currentCooldown > 0.1f ? Mathf.Ceil(currentCooldown).ToString() : "";
                }
                return;
            }
        }
    }

    private void HandleGameStateChanged(GameManager.GameState newState)
    {
        switch (newState)
        {
            case GameManager.GameState.Playing:
                hudPanel?.SetActive(true);
                pauseMenuPanel?.SetActive(false);
                gameOverPanel?.SetActive(false);
                break;
            case GameManager.GameState.Paused:
                hudPanel?.SetActive(false);
                pauseMenuPanel?.SetActive(true);
                gameOverPanel?.SetActive(false);
                break;
            case GameManager.GameState.GameOver:
            case GameManager.GameState.MissionComplete:
                break;
            case GameManager.GameState.MainMenu:
                hudPanel?.SetActive(false);
                pauseMenuPanel?.SetActive(false);
                gameOverPanel?.SetActive(false);
                foreach (var item in activeObjectiveUIs.Values)
                {
                    Destroy(item.gameObject);
                }
                activeObjectiveUIs.Clear();
                break;
        }
    }
}

public class ObjectiveUIItem : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI descriptionText;
    [SerializeField] private TextMeshProUGUI progressText;
    [SerializeField] private GameObject completedCheckmark;

    public string ObjectiveID { get; private set; }

    private void Awake()
    {
        if (descriptionText == null) Debug.LogError("ObjectiveUIItem: Description Text not assigned.", this);
        if (progressText == null) Debug.LogError("ObjectiveUIItem: Progress Text not assigned.", this);
        if (completedCheckmark != null) completedCheckmark.SetActive(false);
    }

    public void Initialize(string id, string initialDescription)
    {
        ObjectiveID = id;
        if (descriptionText != null)
        {
            descriptionText.text = initialDescription;
        }
    }

    public void UpdateObjectiveDisplay(string description, int currentProgress, int targetProgress, bool isCompleted)
    {
        if (descriptionText != null)
        {
            descriptionText.text = description;
        }
        if (progressText != null)
        {
            progressText.text = $"{currentProgress}/{targetProgress}";
            progressText.gameObject.SetActive(!isCompleted);
        }
        if (completedCheckmark != null)
        {
            completedCheckmark.SetActive(isCompleted);
        }

        if (isCompleted)
        {
            if (descriptionText != null) descriptionText.color = Color.green;
        }
    }
}